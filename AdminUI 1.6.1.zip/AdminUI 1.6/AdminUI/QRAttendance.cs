﻿using AdminUI.Models;
using AForge.Video;
using AForge.Video.DirectShow;
using FireSharp.Config;
using FireSharp.Interfaces;
using FireSharp.Response;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PdfSharp.Drawing;
using PdfSharp.Pdf;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Threading.Tasks;
using System.Windows.Forms;
using ZXing;


namespace AdminUI
{
    public partial class QRAttendance : Form
    {
        private FilterInfoCollection videoDevices;
        private VideoCaptureDevice videoSource;
        private Timer scanTimer;

        IFirebaseConfig config = new FirebaseConfig
        {
            AuthSecret = "mA771wfHHaDuyceGgGRt0Bf15LvkqN92pW4h6hbK",
            BasePath = "https://web-based-event-scheduling-default-rtdb.firebaseio.com/"
        };

        IFirebaseClient client;

        public QRAttendance()
        {
            InitializeComponent();
            client = new FireSharp.FirebaseClient(config);
        }

        private async Task LoadEventOptions()
        {
            try
            {
                FirebaseResponse response = await client.GetAsync("events");
                cmbEvents.Items.Clear();

                // Always add default option first
                cmbEvents.Items.Add(new ComboBoxItem("- select event -", ""));

                if (response.Body == "null")
                {
                    cmbEvents.Items.Add(new ComboBoxItem("No events for today", ""));
                    cmbEvents.SelectedIndex = 0;
                    return;
                }

                Dictionary<string, EventData> events = JsonConvert.DeserializeObject<Dictionary<string, EventData>>(response.Body);

                bool hasTodayEvent = false;
                foreach (var ev in events)
                {
                    if (DateTime.TryParse(ev.Value.EventDate, out DateTime parsedDate))
                    {
                        if (parsedDate.Date == DateTime.Today)
                        {
                            cmbEvents.Items.Add(new ComboBoxItem(ev.Value.EventName, ev.Key));
                            hasTodayEvent = true;
                        }
                    }
                }

                if (!hasTodayEvent)
                {
                    cmbEvents.Items.Add(new ComboBoxItem("No events for today", ""));
                }

                cmbEvents.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to load events: " + ex.Message);
            }
        }




        private void btnStartScanning_Click(object sender, EventArgs e)
        {
            if (cmbEvents.SelectedItem == null)
            {
                MessageBox.Show("Please select an event first.");
                return;
            }

            string selectedEventId = (cmbEvents.SelectedItem as ComboBoxItem)?.Value;

            var scannerForm = new QRSCANNING(selectedEventId);

            // Hook event to refresh after scan
            scannerForm.OnAttendanceSaved = () =>
            {
                if (this.IsHandleCreated)
                {
                    this.Invoke((MethodInvoker)delegate
                    {
                        LoadAttendanceData(selectedEventId);
                    });
                }
            };

            scannerForm.ShowDialog();

        }

        public void LoadAttendance()
        {
            if (cmbEvents.SelectedItem is ComboBoxItem selectedEvent && !string.IsNullOrEmpty(selectedEvent.Value))
            {
                LoadAttendanceData(selectedEvent.Value);
            }
        }
        public void ReloadGrid()
        {
            if (cmbEvents.SelectedItem is ComboBoxItem selected)
            {
                LoadAttendanceData(selected.Value);
            }
        }


        private async void ProcessScannedData(string scannedId)
        {
            scannedId = scannedId.Trim().Replace("uid:", "").Trim();
            string eventId = (cmbEvents.SelectedItem as ComboBoxItem)?.Value;

            if (string.IsNullOrEmpty(scannedId) || string.IsNullOrEmpty(eventId))
            {
                MessageBox.Show("Invalid scan or no event selected.");
                return;
            }

            FirebaseResponse response = await client.GetAsync("members/" + scannedId);
            if (response.Body != "null")
            {
                dynamic userData = JsonConvert.DeserializeObject(response.Body);
                SaveAttendance(eventId, scannedId, userData);
                return;
            }

            FirebaseResponse allMembers = await client.GetAsync("members");
            if (allMembers.Body != "null")
            {
                var membersDict = JsonConvert.DeserializeObject<Dictionary<string, dynamic>>(allMembers.Body);

                foreach (var member in membersDict)
                {
                    if (member.Value.uid != null && member.Value.uid == scannedId)
                    {
                        SaveAttendance(eventId, member.Key, member.Value);
                        return;
                    }
                }
            }
            MessageBox.Show($"Scanned ID: '{scannedId}'");


            MessageBox.Show("User not found.");
        }

        private async void SaveAttendance(string eventId, string userId, dynamic userData)
        {
            string timestamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

            var attendance = new Attendance
            {
                Name = $"{userData.FirstName} {userData.LastName}",
                Status = "Present",
                TimeIn = timestamp,
                Remarks = "✔ Checked In",
                Ministry = userData.ministry,
                Zone = userData.zone,
                Chapel = userData.chapel,
                EventUid = eventId,
                MemberUid = userId,
                Comment = "No comment" // default comment; can be overwritten later
            };

            await client.SetAsync($"attendances/{eventId}/{userId}", attendance);

            // Simply reload the data grid
            LoadAttendanceData(eventId);
        }

        private void cmbEvents_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbEvents.SelectedItem is ComboBoxItem selectedEvent)
            {
                LoadAttendanceData(selectedEvent.Value);
            }
        }


        private async void LoadAttendanceData(string eventId)
        {
            try
            {
                FirebaseResponse response = await client.GetAsync("attendances/" + eventId);
                dataGridView1.Rows.Clear();

                if (response.Body == "null")
                {
                    // Handle empty case explicitly
                    return;
                }

                // Add validation for response data
                var data = JsonConvert.DeserializeObject<Dictionary<string, dynamic>>(response.Body);
                if (data == null)
                {
                    MessageBox.Show("Invalid attendance data format");
                    return;
                }

                foreach (var item in data)
                {
                    // Add null checks for each property
                    if (item.Key == "comment") continue;

                    dataGridView1.Rows.Add(
                        item.Value.Name?.ToString() ?? "N/A",
                        item.Value.Status?.ToString() ?? "N/A",
                        item.Value.TimeIn?.ToString() ?? "N/A",
                        item.Value.Remarks?.ToString() ?? "N/A"
                    );
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading attendance: {ex.Message}");
                // Log detailed error if needed
            }
        }

        private async void btnReset_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
        }


        private void guna2Button1_Click(object sender, EventArgs e)
        {

        }

        private void txtComment_TextChanged(object sender, EventArgs e)
        {

        }

        private void cancelBtn_Click(object sender, EventArgs e)
        {

        }

        private async void continueBtn_Click(object sender, EventArgs e)
        {
            ComboBoxItem selectedEvent = cmbEvents.SelectedItem as ComboBoxItem;
            if (selectedEvent == null || string.IsNullOrEmpty(selectedEvent.Value))
            {
                MessageBox.Show("Please select an event.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            MessageBox.Show("Please wait... Saving data to the database.", "Processing", MessageBoxButtons.OK, MessageBoxIcon.Information);

            try
            {
                string eventId = selectedEvent.Value;
                string comment = string.IsNullOrWhiteSpace(txtComment.Text)
                    ? "No comments in this event"
                    : txtComment.Text.Trim();

                // Save comment to Firebase
                await client.SetAsync($"attendances/{eventId}/comment", comment);

                // Load attendance data
                FirebaseResponse attendanceResponse = await client.GetAsync("attendances/" + eventId);
                if (attendanceResponse.Body == "null")
                {
                    MessageBox.Show("No attendance data found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                Dictionary<string, dynamic> data = JsonConvert.DeserializeObject<Dictionary<string, dynamic>>(attendanceResponse.Body);

                // Update each record with comment
                foreach (var entry in data)
                {
                    if (entry.Key == "comment") continue;
                    await client.UpdateAsync($"attendances/{eventId}/{entry.Key}", new { Comment = comment });
                }

                MessageBox.Show("✅ Attendance and comment successfully saved.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"❌ Failed to save attendance: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }




        public class ComboBoxItem
        {
            public string Text { get; set; }
            public string Value { get; set; }

            public ComboBoxItem(string text, string value)
            {
                Text = text;
                Value = value;
            }

            public override string ToString()
            {
                return Text;
            }
        }

        private async void downloadPDFbtn_Click(object sender, EventArgs e)
        {
            ComboBoxItem selectedEvent = cmbEvents.SelectedItem as ComboBoxItem;
            if (selectedEvent == null || string.IsNullOrEmpty(selectedEvent.Value))
            {
                MessageBox.Show("Please select an event to download PDF.", "Missing Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string eventId = selectedEvent.Value;

            try
            {
                // Get event info
                FirebaseResponse eventResponse = await client.GetAsync($"events/{eventId}");
                if (eventResponse.Body == "null")
                {
                    MessageBox.Show("Event not found.");
                    return;
                }

                EventData eventInfo = JsonConvert.DeserializeObject<EventData>(eventResponse.Body);

                // Get attendance data
                FirebaseResponse attendanceResponse = await client.GetAsync($"attendances/{eventId}");
                if (attendanceResponse.Body == "null")
                {
                    MessageBox.Show("No attendance data found for this event.");
                    return;
                }

                var attendanceData = JsonConvert.DeserializeObject<Dictionary<string, dynamic>>(attendanceResponse.Body);
                string comment = attendanceData.ContainsKey("comment") ? attendanceData["comment"].ToString() : "No comments.";
                attendanceData.Remove("comment"); // Remove comment from main data loop

                // Save location
                SaveFileDialog saveDialog = new SaveFileDialog
                {
                    Filter = "PDF files (*.pdf)|*.pdf",
                    FileName = $"{eventInfo.EventName}_Attendance_{DateTime.Now:yyyyMMdd_HHmmss}.pdf"
                };

                if (saveDialog.ShowDialog() != DialogResult.OK) return;

                // Generate PDF
                using (PdfDocument doc = new PdfDocument())
                {
                    PdfPage page = doc.AddPage();
                    XGraphics gfx = XGraphics.FromPdfPage(page);
                    XFont headerFont = new XFont("Arial", 14, XFontStyle.Bold);
                    XFont bodyFont = new XFont("Arial", 10);

                    int yPos = 40;

                    // Title and Header
                    gfx.DrawString("Sta. Ana Parish Church Attendance", headerFont, XBrushes.Black,
                        new XRect(0, yPos, page.Width, page.Height), XStringFormats.TopCenter);
                    yPos += 25;
                    gfx.DrawString($"Event recorded date: {eventInfo.EventDate}", bodyFont, XBrushes.Black,
                        new XRect(0, yPos, page.Width, page.Height), XStringFormats.TopCenter);
                    yPos += 20;
                    gfx.DrawString("Davao City, 8000", bodyFont, XBrushes.Black,
                        new XRect(0, yPos, page.Width, page.Height), XStringFormats.TopCenter);
                    yPos += 30;

                    // Table Header
                    gfx.DrawString("Name", bodyFont, XBrushes.Black, 50, yPos);
                    gfx.DrawString("Time In", bodyFont, XBrushes.Black, 200, yPos);
                    gfx.DrawString("Status", bodyFont, XBrushes.Black, 300, yPos);
                    yPos += 20;

                    // Table Content
                    foreach (var attendee in attendanceData.Values)
                    {
                        if (yPos > page.Height - 60)
                        {
                            page = doc.AddPage();
                            gfx = XGraphics.FromPdfPage(page);
                            yPos = 40;
                        }

                        gfx.DrawString(attendee["Name"]?.ToString(), bodyFont, XBrushes.Black, 50, yPos);
                        gfx.DrawString(attendee["TimeIn"]?.ToString(), bodyFont, XBrushes.Black, 200, yPos);
                        gfx.DrawString(attendee["Status"]?.ToString(), bodyFont, XBrushes.Black, 300, yPos);
                        yPos += 15;
                    }

                    // Comments Section
                    yPos += 20;
                    if (yPos > page.Height - 60)
                    {
                        page = doc.AddPage();
                        gfx = XGraphics.FromPdfPage(page);
                        yPos = 40;
                    }

                    gfx.DrawString("Comments on this event:", bodyFont, XBrushes.Black, 50, yPos);
                    yPos += 15;
                    gfx.DrawString(comment, bodyFont, XBrushes.Black, new XRect(50, yPos, page.Width - 100, page.Height - yPos), XStringFormats.TopLeft);

                    doc.Save(saveDialog.FileName);
                }

                MessageBox.Show("✅ PDF successfully generated and downloaded.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"❌ PDF download failed: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }



        private async void refreshBtn_Click(object sender, EventArgs e)
        {
            await LoadEventOptions();
        }
    }
}
