﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FireSharp.Config;
using FireSharp.Interfaces;
using FireSharp.Response;
using AdminUI.Models;
using Newtonsoft.Json;

namespace AdminUI
{
    public partial class Announcement : Form
    {
        private IFirebaseConfig config = new FirebaseConfig
        {
            AuthSecret = "mA771wfHHaDuyceGgGRt0Bf15LvkqN92pW4h6hbK",
            BasePath = "https://web-based-event-scheduling-default-rtdb.firebaseio.com/"
        };

        private IFirebaseClient client;

        private AdminModel _admin;

        public Announcement(AdminModel admin)
        {
            InitializeComponent();
            _admin = admin;
        }


        private async void Announcement_Load(object sender, EventArgs e)
        {
            this.ControlBox = false;
            client = new FireSharp.FirebaseClient(config);

            if (client == null)
            {
                MessageBox.Show("Firebase connection failed.");
                return;
            }

            await LoadAnnouncementsAsync();
        }

        private async Task LoadAnnouncementsAsync()
        {
            try
            {
                FirebaseResponse response = await client.GetAsync("announcements");

                if (response.Body != "null")
                {
                    var data = JsonConvert.DeserializeObject<Dictionary<string, AnnouncementData>>(response.Body);

                    // Combine DateCreated and TimeCreated into DateTime for sorting
                    var sortedData = data.Values
                        .OrderByDescending(a =>
                        {
                            DateTime dt;
                            DateTime.TryParse($"{a.DateCreated} {a.TimeCreated}", out dt);
                            return dt;
                        })
                        .ToList();

                    guna2DataGridView1.DataSource = sortedData;
                    guna2DataGridView1.ReadOnly = true;
                }
                else
                {
                    MessageBox.Show("No announcements found.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading announcements: " + ex.Message);
            }
        }

        private void addnewBtn_Click(object sender, EventArgs e)
        {
            AddAnnouncement addAnnouncement = new AddAnnouncement(_admin);
            addAnnouncement.FormClosed += async (s, args) => await LoadAnnouncementsAsync();
            addAnnouncement.Show();
        }


        private void viewBtn_Click(object sender, EventArgs e)
        {

            if (guna2DataGridView1.CurrentRow != null && guna2DataGridView1.CurrentRow.DataBoundItem is AnnouncementData selectedAnnouncement)
            {
                ViewAnnouncement viewAnnouncement = new ViewAnnouncement(selectedAnnouncement);
                viewAnnouncement.ShowDialog();
            }
            else
            {
                MessageBox.Show("Please select an announcement to view.");
            }
        }

        private void guna2DataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
