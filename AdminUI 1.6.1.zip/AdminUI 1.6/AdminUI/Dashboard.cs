﻿using AdminUI.Models;
using FireSharp.Config;
using FireSharp.Interfaces;
using FireSharp.Response;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AdminUI.Models;


namespace AdminUI
{
    public partial class Dashboard : Form
    {
        IFirebaseConfig config = new FirebaseConfig
        {
            AuthSecret = "mA771wfHHaDuyceGgGRt0Bf15LvkqN92pW4h6hbK",
            BasePath = "https://web-based-event-scheduling-default-rtdb.firebaseio.com/"
        };

        IFirebaseClient client;

        private AdminModel loggedInAdmin;

        public Dashboard(AdminModel admin)
        {
            InitializeComponent();
            loggedInAdmin = admin;
        }

        private async void Dashboard_Load(object sender, EventArgs e)
        {
            this.ControlBox = false;
            client = new FireSharp.FirebaseClient(config);

            if (client != null)
            {
                await LoadCounts();
            }
            else
            {
                MessageBox.Show("Failed to connect to Firebase.");
            }

            this.ControlBox = false;
            await LoadCounts();
            await LoadDashboardTables();

        }


        private async Task LoadCounts()
        {
            FirebaseResponse membersResponse = await client.GetAsync("members");
            if (membersResponse.Body != "null")
            {
                var members = JsonConvert.DeserializeObject<Dictionary<string, MemberModel>>(membersResponse.Body);
                membersCount.Text = members.Count.ToString();

                // Count members who are explicitly NOT approved
                int pendingCount = members.Values.Count(m => m.Approved == false);
                pendingmemCount.Text = pendingCount.ToString();
            }


            // Events count
            FirebaseResponse eventsResponse = await client.GetAsync("events");
            if (eventsResponse.Body != "null")
            {
                var events = JsonConvert.DeserializeObject<Dictionary<string, dynamic>>(eventsResponse.Body);
                eventscount.Text = events.Count.ToString();
            }

            // Announcements count
            FirebaseResponse announcementsResponse = await client.GetAsync("announcements");
            if (announcementsResponse.Body != "null")
            {
                var announcements = JsonConvert.DeserializeObject<Dictionary<string, dynamic>>(announcementsResponse.Body);
                announcementCount.Text = announcements.Count.ToString();
            }
        }

        private async Task LoadDashboardTables()
        {
            // --- Upcoming Events (EventName, EventDate, EventTime) ---
            FirebaseResponse eventsRes = await client.GetAsync("events");
            if (eventsRes.Body != "null")
            {
                var allEvents = JsonConvert.DeserializeObject<Dictionary<string, EventData>>(eventsRes.Body);
                var upcomingEvents = allEvents.Values
                    .Where(e => DateTime.TryParse(e.EventDate, out var eventDate) && eventDate >= DateTime.Today)
                    .OrderBy(e => DateTime.Parse(e.EventDate))
                    .Select(e => new
                    {
                        EventName = e.EventName,
                        EventDate = DateTime.Parse(e.EventDate).ToString("MMM dd, yyyy"),
                        EventTime = e.EventTime
                    })
                    .ToList();

                datagridEvents.DataSource = upcomingEvents;
            }

            // --- New Members (Full Name, Position, RegisteredAt) ---
            FirebaseResponse membersRes = await client.GetAsync("members");
            if (membersRes.Body != "null")
            {
                var allMembers = JsonConvert.DeserializeObject<Dictionary<string, MemberModel>>(membersRes.Body);
                var sortedMembers = allMembers.Values
                    .Where(m => DateTime.TryParse(m.RegisteredAt, out _))
                    .OrderByDescending(m => DateTime.Parse(m.RegisteredAt))
                    .Select(m => new
                    {
                        FullName = $"{m.FirstName} {m.MiddleName} {m.LastName}".Trim(),
                        Position = m.Position,
                        RegisteredAt = DateTime.Parse(m.RegisteredAt).ToString("MMM dd, yyyy")
                    })
                    .ToList();

                datagridRecentMem.DataSource = sortedMembers;
            }

            // --- New Announcements (No change — but still projecting if needed) ---
            FirebaseResponse announceRes = await client.GetAsync("announcements");
            if (announceRes.Body != "null")
            {
                var allAnnouncements = JsonConvert.DeserializeObject<Dictionary<string, AnnouncementData>>(announceRes.Body);
                var sortedAnnouncements = allAnnouncements.Values
                    .Where(a => DateTime.TryParse(a.DateCreated, out _))
                    .OrderByDescending(a => DateTime.Parse(a.DateCreated))
                    .Select(a => new
                    {
                        a.AnnouncementName,
                        a.Description,
                        a.Reminders,
                        DateCreated = DateTime.Parse(a.DateCreated).ToString("MMM dd, yyyy"),
                        a.TimeCreated
                    })
                    .ToList();

                datagridnewAnnouncement.DataSource = sortedAnnouncements;
            }
        }


        private void guna2ControlBox2_Click(object sender, EventArgs e)
        {

        }

        private void guna2ControlBox1_Click(object sender, EventArgs e)
        {

        }

        private void guna2HtmlLabel2_Click(object sender, EventArgs e)
        {

        }

        private void membersBtn_Click(object sender, EventArgs e)
        {
            Members membersForm = new Members();
            membersForm.Show();
        }

        private void eventsBtn_Click(object sender, EventArgs e)
        {
            Events eventsForm = new Events(loggedInAdmin);
            eventsForm.Show();
        }

        private void pendingBtn_Click(object sender, EventArgs e)
        {
            PendingMembers pendingsForm = new PendingMembers();
            pendingsForm.Show();
        }

        private void AllEventsBtn_Click(object sender, EventArgs e)
        {
            Events eventsForm = new Events(loggedInAdmin);
            eventsForm.Show();
        }

        private void AllMembersBtn_Click(object sender, EventArgs e)
        {
            Members membersForm = new Members();
            membersForm.Show();
        }

        private void membersCount_Click(object sender, EventArgs e)
        {

        }

        private void eventscount_Click(object sender, EventArgs e)
        {

        }

        private void pendingmemCount_Click(object sender, EventArgs e)
        {

        }

        private void announcementCount_Click(object sender, EventArgs e)
        {

        }

        private void datagridEvents_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void datagridRecentMem_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void datagridnewAnnouncement_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
