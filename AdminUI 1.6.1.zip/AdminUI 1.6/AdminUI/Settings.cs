﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AdminUI.Models;

namespace AdminUI
{
    public partial class Settings : Form
    {

        private AdminModel loggedInAdmin;
        private Home homeForm;

        public Settings(AdminModel admin, Home home)
        {
            InitializeComponent();
            loggedInAdmin = admin;
            homeForm = home;
        }

        private void Settings_Load(object sender, EventArgs e)
        {
            this.ControlBox = false;

            if (loggedInAdmin != null)
            {
                adminUsername.Text = loggedInAdmin.adminUsername;
                AdminName.Text = loggedInAdmin.adminName;
                adminEmail.Text = loggedInAdmin.adminEmail;
                // Don't load the password for security
            }
        }




        private void guna2GradientPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void guna2Button4_Click(object sender, EventArgs e)
        {

        }

        private void createBtn_Click(object sender, EventArgs e)
        {
            CreateAdmin createAdmin = new CreateAdmin();
            createAdmin.Show();
        }

        private void adminUsername_TextChanged(object sender, EventArgs e)
        {

        }

        private void AdminName_TextChanged(object sender, EventArgs e)
        {

        }

        private void adminEmail_TextChanged(object sender, EventArgs e)
        {

        }

        private void logoutBtn_Click(object sender, EventArgs e)
        {
            var confirmResult = MessageBox.Show("Are you sure you want to log out?", "Confirm Logout", MessageBoxButtons.YesNo);
            if (confirmResult == DialogResult.Yes)
            {
                homeForm.Close(); // This closes the main Home form (and by extension, Settings)
                AdminLogin loginForm = new AdminLogin();
                loginForm.Show();
            }
        }

    }
}
