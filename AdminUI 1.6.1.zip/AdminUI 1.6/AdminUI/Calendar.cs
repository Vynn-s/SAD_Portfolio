﻿using FireSharp.Config;
using FireSharp.Interfaces;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AdminUI.Models; // Ensure EventData model is included
using Newtonsoft.Json;


namespace AdminUI
{
    public partial class Calendar : Form
    {
        IFirebaseConfig config = new FirebaseConfig
        {
            AuthSecret = "mA771wfHHaDuyceGgGRt0Bf15LvkqN92pW4h6hbK",
            BasePath = "https://web-based-event-scheduling-default-rtdb.firebaseio.com/"
        };

        IFirebaseClient client;
        private DateTime currentDate;
        private AdminModel loggedInAdmin;

        public Calendar(AdminModel admin)
        {
            InitializeComponent();
            loggedInAdmin = admin;

        }

        


        private void Calendar_Load(object sender, EventArgs e)
        {
            currentDate = DateTime.Now;
            DisplayCalendar(currentDate);
            this.ControlBox = false;
        }

        private void DisplayCalendar(DateTime date)
        {
            int month = date.Month;
            int year = date.Year;
            daycontainer.Controls.Clear();

            string monthName = DateTimeFormatInfo.CurrentInfo.GetMonthName(month);
            lbdate.Text = monthName + " " + year;

            DateTime startOfMonth = new DateTime(year, month, 1);
            int daysInMonth = DateTime.DaysInMonth(year, month);
            int startDayOfWeek = Convert.ToInt32(startOfMonth.DayOfWeek.ToString("d")) + 1;

            // Create blank spaces for the first few days of the month
            for (int i = 1; i < startDayOfWeek; i++)
            {
                UserControlBlank ucblank = new UserControlBlank();
                daycontainer.Controls.Add(ucblank);
            }

            // Add day buttons for the actual days in the month
            for (int i = 1; i <= daysInMonth; i++)
            {
                UserControlDays ucdays = new UserControlDays();
                ucdays.days(i);
                daycontainer.Controls.Add(ucdays);
            }
        }

        private void btnprevious_Click(object sender, EventArgs e)
        {
            currentDate = currentDate.AddMonths(-1);
            DisplayCalendar(currentDate);
        }

        private void viewEventsBtn_Click(object sender, EventArgs e)
        {
            Events eventsForm = new Events(loggedInAdmin);
            eventsForm.Show();
        }

        private void refreshBtn_Click(object sender, EventArgs e)
        {
            DisplayCalendar(currentDate);
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            currentDate = currentDate.AddMonths(1);
            DisplayCalendar(currentDate);
        }
    }
}
