﻿using FireSharp.Config;
using FireSharp.Interfaces;
using FireSharp.Response;
using System;
using System.Collections.Generic;
using System.Windows.Forms;
using AdminUI.Models; // Create a model class for EventData
using Newtonsoft.Json;
using System.Linq;



namespace AdminUI
{
    public partial class CreateEvent : Form
    {
        IFirebaseConfig config = new FirebaseConfig
        {
            AuthSecret = "mA771wfHHaDuyceGgGRt0Bf15LvkqN92pW4h6hbK",
            BasePath = "https://web-based-event-scheduling-default-rtdb.firebaseio.com/"
        };

        IFirebaseClient client;

        private AdminModel _admin;
        public CreateEvent(AdminModel admin)
        {
            InitializeComponent();
            _admin = admin;
            client = new FireSharp.FirebaseClient(config);

            if (client == null)
            {
                MessageBox.Show("Firebase connection failed!");
            }

            this.Load += CreateEvent_Load;
        }



        private void CreateEvent_Load(object sender, EventArgs e)
        {
            LoadEventTypes();
        }

        private async void btnCreate_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(_admin.FullName))
            {
                MessageBox.Show("Admin not recognized. You must be logged in to publish an event.");
                return;
            }

            if (string.IsNullOrWhiteSpace(txtEventName.Text) ||
                string.IsNullOrWhiteSpace(txtTime.Text) ||
                cmbEventType.SelectedItem == null ||
                string.IsNullOrWhiteSpace(txtDescription.Text))
            {
                MessageBox.Show("Please fill in all required fields.");
                return;
            }

            // ✅ Prevent creating events in the past
            DateTime selectedDate = dtpDate.Value.Date;
            DateTime today = DateTime.Today;

            if (selectedDate < today)
            {
                MessageBox.Show("You cannot create an event in the past.");
                return;
            }

            string eventId = Guid.NewGuid().ToString();

            var eventData = new EventData
            {
                EventID = eventId,
                EventName = txtEventName.Text.Trim(),
                EventDate = dtpDate.Value.ToString("yyyy-MM-dd"),
                EventTime = txtTime.Text.Trim(),
                EventType = cmbEventType.SelectedItem.ToString(),
                EventVenue = txtVenue.Text.Trim(),
                EventDescription = txtDescription.Text.Trim(),
                Published = _admin.FullName
            };

            SetResponse response = await client.SetAsync("events/" + eventId, eventData);
            if (response.StatusCode == System.Net.HttpStatusCode.OK)
            {
                MessageBox.Show("Event created successfully!");
                this.Close();
            }
            else
            {
                MessageBox.Show("Failed to create event.");
            }
        }


        private async void LoadEventTypes()
        {
            try
            {
                FirebaseResponse response = await client.GetAsync("dropdownOptions/events");

                if (response.Body != "null")
                {
                    // Deserialize as a List<string> since the data is a JSON array
                    List<string> eventTypes = JsonConvert.DeserializeObject<List<string>>(response.Body);

                    cmbEventType.Items.Clear();
                    foreach (var type in eventTypes)
                    {
                        cmbEventType.Items.Add(type);
                    }

                    if (cmbEventType.Items.Count > 0)
                        cmbEventType.SelectedIndex = 0;
                }
                else
                {
                    MessageBox.Show("No event types found in the database.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading events: " + ex.Message);
            }
        }
    }
}
