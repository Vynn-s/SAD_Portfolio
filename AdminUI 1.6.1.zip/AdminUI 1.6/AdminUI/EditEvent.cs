﻿using FireSharp.Config;
using FireSharp.Interfaces;
using FireSharp.Response;
using System;
using System.Collections.Generic;
using System.Windows.Forms;
using AdminUI.Models;
using Newtonsoft.Json;

namespace AdminUI
{
    public partial class EditEvent : Form
    {
        IFirebaseConfig config = new FirebaseConfig
        {
            AuthSecret = "mA771wfHHaDuyceGgGRt0Bf15LvkqN92pW4h6hbK",
            BasePath = "https://web-based-event-scheduling-default-rtdb.firebaseio.com/"
        };

        IFirebaseClient client;
        private AdminModel _admin;
        private EventData _currentEvent;

        public EditEvent(AdminModel admin, string eventId)
        {
            InitializeComponent();
            _admin = admin;
            client = new FireSharp.FirebaseClient(config);

            if (client == null)
            {
                MessageBox.Show("Firebase connection failed!");
            }

            LoadEventData(eventId);
            LoadEventTypes();
        }

        private async void LoadEventData(string eventId)
        {
            try
            {
                FirebaseResponse response = await client.GetAsync($"events/{eventId}");
                if (response.Body != "null")
                {
                    _currentEvent = response.ResultAs<EventData>();
                    PopulateFormFields();
                }
                else
                {
                    MessageBox.Show("Event not found!");
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading event: {ex.Message}");
                this.Close();
            }
        }

        private void PopulateFormFields()
        {
            txtEventName.Text = _currentEvent.EventName;
            dtpDate.Value = DateTime.Parse(_currentEvent.EventDate);
            txtTime.Text = _currentEvent.EventTime;
            txtVenue.Text = _currentEvent.EventVenue;
            txtDescription.Text = _currentEvent.EventDescription;

            // Select the event type in combobox if it exists
            if (cmbEventType.Items.Contains(_currentEvent.EventType))
            {
                cmbEventType.SelectedItem = _currentEvent.EventType;
            }
        }

        private async void LoadEventTypes()
        {
            try
            {
                FirebaseResponse response = await client.GetAsync("dropdownOptions/events");
                if (response.Body != "null")
                {
                    List<string> eventTypes = JsonConvert.DeserializeObject<List<string>>(response.Body);
                    cmbEventType.Items.Clear();
                    foreach (var type in eventTypes)
                    {
                        cmbEventType.Items.Add(type);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading event types: " + ex.Message);
            }
        }

        private async void btnSave_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(_admin.FullName))
            {
                MessageBox.Show("Admin not recognized. You must be logged in to edit an event.");
                return;
            }

            if (string.IsNullOrWhiteSpace(txtEventName.Text) ||
                string.IsNullOrWhiteSpace(txtTime.Text) ||
                cmbEventType.SelectedItem == null ||
                string.IsNullOrWhiteSpace(txtDescription.Text))
            {
                MessageBox.Show("Please fill in all required fields.");
                return;
            }

            var updatedEvent = new EventData
            {
                EventID = _currentEvent.EventID,
                EventName = txtEventName.Text.Trim(),
                EventDate = dtpDate.Value.ToString("yyyy-MM-dd"),
                EventTime = txtTime.Text.Trim(),
                EventType = cmbEventType.SelectedItem.ToString(),
                EventVenue = txtVenue.Text.Trim(),
                EventDescription = txtDescription.Text.Trim(),
                Published = _currentEvent.Published // Maintain original publisher
            };

            try
            {
                FirebaseResponse response = await client.UpdateAsync($"events/{_currentEvent.EventID}", updatedEvent);
                if (response.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    MessageBox.Show("Event updated successfully!");
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Failed to update event.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error updating event: {ex.Message}");
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}