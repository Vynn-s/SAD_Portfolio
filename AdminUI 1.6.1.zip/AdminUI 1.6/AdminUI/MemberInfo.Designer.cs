﻿namespace AdminUI
{
    partial class MemberInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.QRPictureBox = new System.Windows.Forms.PictureBox();
            this.guna2ContextMenuStrip1 = new Guna.UI2.WinForms.Guna2ContextMenuStrip();
            this.guna2Htmllabel = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.lblFirstName = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.lblLastName = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel3 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.lblMiddleName = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel5 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.lblMinistry = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel7 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel8 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.lblUsername = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.lblPosition = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel11 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.lblContact = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel13 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel14 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.lblEmail = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.lblTransparochial = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel17 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.lblAddress = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.lblZone = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel6 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.lblChapel = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.btnDownloadPDF = new Guna.UI2.WinForms.Guna2Button();
            this.guna2GradientPanel1 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.comboStat = new Guna.UI2.WinForms.Guna2ComboBox();
            this.saveChanges = new Guna.UI2.WinForms.Guna2Button();
            this.guna2GradientPanel2 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.sendToemailBtn = new Guna.UI2.WinForms.Guna2Button();
            this.guna2HtmlLabel9 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2ControlBox1 = new Guna.UI2.WinForms.Guna2ControlBox();
            this.guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.QRPictureBox)).BeginInit();
            this.guna2GradientPanel1.SuspendLayout();
            this.guna2GradientPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // QRPictureBox
            // 
            this.QRPictureBox.Location = new System.Drawing.Point(73, 46);
            this.QRPictureBox.Name = "QRPictureBox";
            this.QRPictureBox.Size = new System.Drawing.Size(178, 162);
            this.QRPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.QRPictureBox.TabIndex = 0;
            this.QRPictureBox.TabStop = false;
            // 
            // guna2ContextMenuStrip1
            // 
            this.guna2ContextMenuStrip1.Name = "guna2ContextMenuStrip1";
            this.guna2ContextMenuStrip1.RenderStyle.ArrowColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.guna2ContextMenuStrip1.RenderStyle.BorderColor = System.Drawing.Color.Gainsboro;
            this.guna2ContextMenuStrip1.RenderStyle.ColorTable = null;
            this.guna2ContextMenuStrip1.RenderStyle.RoundedEdges = true;
            this.guna2ContextMenuStrip1.RenderStyle.SelectionArrowColor = System.Drawing.Color.White;
            this.guna2ContextMenuStrip1.RenderStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.guna2ContextMenuStrip1.RenderStyle.SelectionForeColor = System.Drawing.Color.White;
            this.guna2ContextMenuStrip1.RenderStyle.SeparatorColor = System.Drawing.Color.Gainsboro;
            this.guna2ContextMenuStrip1.RenderStyle.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            this.guna2ContextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // guna2Htmllabel
            // 
            this.guna2Htmllabel.BackColor = System.Drawing.Color.Transparent;
            this.guna2Htmllabel.Font = new System.Drawing.Font("Inter Black", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Htmllabel.Location = new System.Drawing.Point(467, 33);
            this.guna2Htmllabel.Name = "guna2Htmllabel";
            this.guna2Htmllabel.Size = new System.Drawing.Size(53, 24);
            this.guna2Htmllabel.TabIndex = 2;
            this.guna2Htmllabel.Text = "Name:";
            // 
            // lblFirstName
            // 
            this.lblFirstName.BackColor = System.Drawing.Color.Transparent;
            this.lblFirstName.Font = new System.Drawing.Font("Inter Medium", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFirstName.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.lblFirstName.Location = new System.Drawing.Point(467, 62);
            this.lblFirstName.Name = "lblFirstName";
            this.lblFirstName.Size = new System.Drawing.Size(87, 25);
            this.lblFirstName.TabIndex = 2;
            this.lblFirstName.Text = "Name Here";
            // 
            // guna2HtmlLabel1
            // 
            this.guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel1.Font = new System.Drawing.Font("Inter Black", 11.25F, System.Drawing.FontStyle.Bold);
            this.guna2HtmlLabel1.Location = new System.Drawing.Point(814, 33);
            this.guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            this.guna2HtmlLabel1.Size = new System.Drawing.Size(86, 24);
            this.guna2HtmlLabel1.TabIndex = 2;
            this.guna2HtmlLabel1.Text = "Last name:";
            // 
            // lblLastName
            // 
            this.lblLastName.BackColor = System.Drawing.Color.Transparent;
            this.lblLastName.Font = new System.Drawing.Font("Inter Medium", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLastName.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.lblLastName.Location = new System.Drawing.Point(814, 62);
            this.lblLastName.Name = "lblLastName";
            this.lblLastName.Size = new System.Drawing.Size(83, 25);
            this.lblLastName.TabIndex = 2;
            this.lblLastName.Text = "Last Name";
            // 
            // guna2HtmlLabel3
            // 
            this.guna2HtmlLabel3.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel3.Font = new System.Drawing.Font("Inter Black", 11.25F, System.Drawing.FontStyle.Bold);
            this.guna2HtmlLabel3.Location = new System.Drawing.Point(640, 33);
            this.guna2HtmlLabel3.Name = "guna2HtmlLabel3";
            this.guna2HtmlLabel3.Size = new System.Drawing.Size(107, 24);
            this.guna2HtmlLabel3.TabIndex = 2;
            this.guna2HtmlLabel3.Text = "Middle Name:";
            // 
            // lblMiddleName
            // 
            this.lblMiddleName.BackColor = System.Drawing.Color.Transparent;
            this.lblMiddleName.Font = new System.Drawing.Font("Inter Medium", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMiddleName.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.lblMiddleName.Location = new System.Drawing.Point(640, 62);
            this.lblMiddleName.Name = "lblMiddleName";
            this.lblMiddleName.Size = new System.Drawing.Size(108, 25);
            this.lblMiddleName.TabIndex = 2;
            this.lblMiddleName.Text = "Middle Name:";
            // 
            // guna2HtmlLabel5
            // 
            this.guna2HtmlLabel5.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel5.Font = new System.Drawing.Font("Inter Black", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel5.Location = new System.Drawing.Point(467, 105);
            this.guna2HtmlLabel5.Name = "guna2HtmlLabel5";
            this.guna2HtmlLabel5.Size = new System.Drawing.Size(73, 24);
            this.guna2HtmlLabel5.TabIndex = 2;
            this.guna2HtmlLabel5.Text = "Ministry:";
            // 
            // lblMinistry
            // 
            this.lblMinistry.BackColor = System.Drawing.Color.Transparent;
            this.lblMinistry.Font = new System.Drawing.Font("Inter Medium", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMinistry.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.lblMinistry.Location = new System.Drawing.Point(467, 137);
            this.lblMinistry.Name = "lblMinistry";
            this.lblMinistry.Size = new System.Drawing.Size(70, 25);
            this.lblMinistry.TabIndex = 2;
            this.lblMinistry.Text = "Ministry:";
            // 
            // guna2HtmlLabel7
            // 
            this.guna2HtmlLabel7.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel7.Font = new System.Drawing.Font("Inter Black", 11.25F, System.Drawing.FontStyle.Bold);
            this.guna2HtmlLabel7.Location = new System.Drawing.Point(814, 105);
            this.guna2HtmlLabel7.Name = "guna2HtmlLabel7";
            this.guna2HtmlLabel7.Size = new System.Drawing.Size(87, 24);
            this.guna2HtmlLabel7.TabIndex = 2;
            this.guna2HtmlLabel7.Text = "Username:";
            // 
            // guna2HtmlLabel8
            // 
            this.guna2HtmlLabel8.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel8.Font = new System.Drawing.Font("Inter Black", 11.25F, System.Drawing.FontStyle.Bold);
            this.guna2HtmlLabel8.Location = new System.Drawing.Point(640, 105);
            this.guna2HtmlLabel8.Name = "guna2HtmlLabel8";
            this.guna2HtmlLabel8.Size = new System.Drawing.Size(70, 24);
            this.guna2HtmlLabel8.TabIndex = 2;
            this.guna2HtmlLabel8.Text = "Position:";
            // 
            // lblUsername
            // 
            this.lblUsername.BackColor = System.Drawing.Color.Transparent;
            this.lblUsername.Font = new System.Drawing.Font("Inter Medium", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUsername.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.lblUsername.Location = new System.Drawing.Point(814, 137);
            this.lblUsername.Name = "lblUsername";
            this.lblUsername.Size = new System.Drawing.Size(83, 25);
            this.lblUsername.TabIndex = 2;
            this.lblUsername.Text = "UserName";
            // 
            // lblPosition
            // 
            this.lblPosition.BackColor = System.Drawing.Color.Transparent;
            this.lblPosition.Font = new System.Drawing.Font("Inter Medium", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPosition.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.lblPosition.Location = new System.Drawing.Point(640, 137);
            this.lblPosition.Name = "lblPosition";
            this.lblPosition.Size = new System.Drawing.Size(65, 25);
            this.lblPosition.TabIndex = 2;
            this.lblPosition.Text = "Position";
            // 
            // guna2HtmlLabel11
            // 
            this.guna2HtmlLabel11.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel11.Font = new System.Drawing.Font("Inter Black", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel11.Location = new System.Drawing.Point(467, 273);
            this.guna2HtmlLabel11.Name = "guna2HtmlLabel11";
            this.guna2HtmlLabel11.Size = new System.Drawing.Size(93, 24);
            this.guna2HtmlLabel11.TabIndex = 2;
            this.guna2HtmlLabel11.Text = "Contact No.";
            // 
            // lblContact
            // 
            this.lblContact.BackColor = System.Drawing.Color.Transparent;
            this.lblContact.Font = new System.Drawing.Font("Inter Medium", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblContact.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.lblContact.Location = new System.Drawing.Point(467, 305);
            this.lblContact.Name = "lblContact";
            this.lblContact.Size = new System.Drawing.Size(128, 25);
            this.lblContact.TabIndex = 2;
            this.lblContact.Text = "Contact Number";
            // 
            // guna2HtmlLabel13
            // 
            this.guna2HtmlLabel13.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel13.Font = new System.Drawing.Font("Inter Black", 11.25F, System.Drawing.FontStyle.Bold);
            this.guna2HtmlLabel13.Location = new System.Drawing.Point(640, 351);
            this.guna2HtmlLabel13.Name = "guna2HtmlLabel13";
            this.guna2HtmlLabel13.Size = new System.Drawing.Size(49, 24);
            this.guna2HtmlLabel13.TabIndex = 2;
            this.guna2HtmlLabel13.Text = "Email:";
            // 
            // guna2HtmlLabel14
            // 
            this.guna2HtmlLabel14.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel14.Font = new System.Drawing.Font("Inter Black", 11.25F, System.Drawing.FontStyle.Bold);
            this.guna2HtmlLabel14.Location = new System.Drawing.Point(467, 191);
            this.guna2HtmlLabel14.Name = "guna2HtmlLabel14";
            this.guna2HtmlLabel14.Size = new System.Drawing.Size(125, 24);
            this.guna2HtmlLabel14.TabIndex = 2;
            this.guna2HtmlLabel14.Text = "Transparochial:";
            // 
            // lblEmail
            // 
            this.lblEmail.BackColor = System.Drawing.Color.Transparent;
            this.lblEmail.Font = new System.Drawing.Font("Inter Medium", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmail.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.lblEmail.Location = new System.Drawing.Point(640, 383);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(44, 25);
            this.lblEmail.TabIndex = 2;
            this.lblEmail.Text = "gmail";
            // 
            // lblTransparochial
            // 
            this.lblTransparochial.BackColor = System.Drawing.Color.Transparent;
            this.lblTransparochial.Font = new System.Drawing.Font("Inter Medium", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTransparochial.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.lblTransparochial.Location = new System.Drawing.Point(467, 223);
            this.lblTransparochial.Name = "lblTransparochial";
            this.lblTransparochial.Size = new System.Drawing.Size(126, 25);
            this.lblTransparochial.TabIndex = 2;
            this.lblTransparochial.Text = "Transparochial?";
            // 
            // guna2HtmlLabel17
            // 
            this.guna2HtmlLabel17.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel17.Font = new System.Drawing.Font("Inter Black", 11.25F, System.Drawing.FontStyle.Bold);
            this.guna2HtmlLabel17.Location = new System.Drawing.Point(467, 351);
            this.guna2HtmlLabel17.Name = "guna2HtmlLabel17";
            this.guna2HtmlLabel17.Size = new System.Drawing.Size(121, 24);
            this.guna2HtmlLabel17.TabIndex = 2;
            this.guna2HtmlLabel17.Text = "Home Address:";
            // 
            // lblAddress
            // 
            this.lblAddress.BackColor = System.Drawing.Color.Transparent;
            this.lblAddress.Font = new System.Drawing.Font("Inter Medium", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddress.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.lblAddress.Location = new System.Drawing.Point(467, 383);
            this.lblAddress.Name = "lblAddress";
            this.lblAddress.Size = new System.Drawing.Size(87, 25);
            this.lblAddress.TabIndex = 2;
            this.lblAddress.Text = "Name Here";
            // 
            // guna2HtmlLabel2
            // 
            this.guna2HtmlLabel2.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel2.Font = new System.Drawing.Font("Inter Black", 11.25F, System.Drawing.FontStyle.Bold);
            this.guna2HtmlLabel2.Location = new System.Drawing.Point(640, 191);
            this.guna2HtmlLabel2.Name = "guna2HtmlLabel2";
            this.guna2HtmlLabel2.Size = new System.Drawing.Size(47, 24);
            this.guna2HtmlLabel2.TabIndex = 2;
            this.guna2HtmlLabel2.Text = "Zone:";
            // 
            // lblZone
            // 
            this.lblZone.BackColor = System.Drawing.Color.Transparent;
            this.lblZone.Font = new System.Drawing.Font("Inter Medium", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblZone.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.lblZone.Location = new System.Drawing.Point(640, 223);
            this.lblZone.Name = "lblZone";
            this.lblZone.Size = new System.Drawing.Size(68, 25);
            this.lblZone.TabIndex = 2;
            this.lblZone.Text = "No Zone";
            // 
            // guna2HtmlLabel6
            // 
            this.guna2HtmlLabel6.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel6.Font = new System.Drawing.Font("Inter Black", 11.25F, System.Drawing.FontStyle.Bold);
            this.guna2HtmlLabel6.Location = new System.Drawing.Point(814, 191);
            this.guna2HtmlLabel6.Name = "guna2HtmlLabel6";
            this.guna2HtmlLabel6.Size = new System.Drawing.Size(62, 24);
            this.guna2HtmlLabel6.TabIndex = 2;
            this.guna2HtmlLabel6.Text = "Chapel:";
            // 
            // lblChapel
            // 
            this.lblChapel.AutoSize = false;
            this.lblChapel.BackColor = System.Drawing.Color.Transparent;
            this.lblChapel.Font = new System.Drawing.Font("Inter Medium", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChapel.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.lblChapel.Location = new System.Drawing.Point(814, 223);
            this.lblChapel.Name = "lblChapel";
            this.lblChapel.Size = new System.Drawing.Size(173, 159);
            this.lblChapel.TabIndex = 2;
            this.lblChapel.Text = "No Zone";
            // 
            // btnDownloadPDF
            // 
            this.btnDownloadPDF.BackColor = System.Drawing.Color.Transparent;
            this.btnDownloadPDF.BorderRadius = 18;
            this.btnDownloadPDF.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnDownloadPDF.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnDownloadPDF.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnDownloadPDF.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnDownloadPDF.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnDownloadPDF.Font = new System.Drawing.Font("Inter Black", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDownloadPDF.ForeColor = System.Drawing.Color.White;
            this.btnDownloadPDF.Location = new System.Drawing.Point(56, 255);
            this.btnDownloadPDF.Name = "btnDownloadPDF";
            this.btnDownloadPDF.Size = new System.Drawing.Size(214, 45);
            this.btnDownloadPDF.TabIndex = 35;
            this.btnDownloadPDF.Text = "Download QR";
            this.btnDownloadPDF.Click += new System.EventHandler(this.btnDownloadPDF_Click);
            // 
            // guna2GradientPanel1
            // 
            this.guna2GradientPanel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientPanel1.BorderRadius = 20;
            this.guna2GradientPanel1.Controls.Add(this.comboStat);
            this.guna2GradientPanel1.Controls.Add(this.saveChanges);
            this.guna2GradientPanel1.Controls.Add(this.guna2GradientPanel2);
            this.guna2GradientPanel1.Controls.Add(this.guna2HtmlLabel9);
            this.guna2GradientPanel1.Controls.Add(this.guna2HtmlLabel3);
            this.guna2GradientPanel1.Controls.Add(this.lblTransparochial);
            this.guna2GradientPanel1.Controls.Add(this.guna2HtmlLabel1);
            this.guna2GradientPanel1.Controls.Add(this.guna2Htmllabel);
            this.guna2GradientPanel1.Controls.Add(this.lblEmail);
            this.guna2GradientPanel1.Controls.Add(this.lblPosition);
            this.guna2GradientPanel1.Controls.Add(this.lblUsername);
            this.guna2GradientPanel1.Controls.Add(this.guna2HtmlLabel14);
            this.guna2GradientPanel1.Controls.Add(this.lblMiddleName);
            this.guna2GradientPanel1.Controls.Add(this.guna2HtmlLabel8);
            this.guna2GradientPanel1.Controls.Add(this.guna2HtmlLabel13);
            this.guna2GradientPanel1.Controls.Add(this.lblLastName);
            this.guna2GradientPanel1.Controls.Add(this.guna2HtmlLabel7);
            this.guna2GradientPanel1.Controls.Add(this.lblChapel);
            this.guna2GradientPanel1.Controls.Add(this.lblZone);
            this.guna2GradientPanel1.Controls.Add(this.lblAddress);
            this.guna2GradientPanel1.Controls.Add(this.lblContact);
            this.guna2GradientPanel1.Controls.Add(this.guna2HtmlLabel6);
            this.guna2GradientPanel1.Controls.Add(this.guna2HtmlLabel2);
            this.guna2GradientPanel1.Controls.Add(this.guna2HtmlLabel17);
            this.guna2GradientPanel1.Controls.Add(this.lblMinistry);
            this.guna2GradientPanel1.Controls.Add(this.guna2HtmlLabel11);
            this.guna2GradientPanel1.Controls.Add(this.guna2HtmlLabel5);
            this.guna2GradientPanel1.Controls.Add(this.lblFirstName);
            this.guna2GradientPanel1.FillColor = System.Drawing.Color.White;
            this.guna2GradientPanel1.FillColor2 = System.Drawing.Color.White;
            this.guna2GradientPanel1.Location = new System.Drawing.Point(43, 43);
            this.guna2GradientPanel1.Name = "guna2GradientPanel1";
            this.guna2GradientPanel1.Padding = new System.Windows.Forms.Padding(30);
            this.guna2GradientPanel1.Size = new System.Drawing.Size(1020, 531);
            this.guna2GradientPanel1.TabIndex = 36;
            // 
            // comboStat
            // 
            this.comboStat.BackColor = System.Drawing.Color.Transparent;
            this.comboStat.BorderRadius = 12;
            this.comboStat.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.comboStat.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboStat.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.comboStat.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.comboStat.Font = new System.Drawing.Font("Inter Medium", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboStat.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.comboStat.ItemHeight = 30;
            this.comboStat.Location = new System.Drawing.Point(640, 305);
            this.comboStat.Name = "comboStat";
            this.comboStat.Size = new System.Drawing.Size(140, 36);
            this.comboStat.TabIndex = 41;
            this.comboStat.SelectedIndexChanged += new System.EventHandler(this.comboStat_SelectedIndexChanged);
            // 
            // saveChanges
            // 
            this.saveChanges.BackColor = System.Drawing.Color.Transparent;
            this.saveChanges.BorderRadius = 18;
            this.saveChanges.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.saveChanges.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.saveChanges.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.saveChanges.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.saveChanges.FillColor = System.Drawing.Color.Tan;
            this.saveChanges.Font = new System.Drawing.Font("Inter Black", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saveChanges.ForeColor = System.Drawing.Color.White;
            this.saveChanges.Location = new System.Drawing.Point(814, 430);
            this.saveChanges.Name = "saveChanges";
            this.saveChanges.Size = new System.Drawing.Size(173, 45);
            this.saveChanges.TabIndex = 40;
            this.saveChanges.Text = "Save Changes";
            this.saveChanges.Click += new System.EventHandler(this.saveChanges_Click);
            // 
            // guna2GradientPanel2
            // 
            this.guna2GradientPanel2.BorderRadius = 20;
            this.guna2GradientPanel2.Controls.Add(this.sendToemailBtn);
            this.guna2GradientPanel2.Controls.Add(this.btnDownloadPDF);
            this.guna2GradientPanel2.Controls.Add(this.QRPictureBox);
            this.guna2GradientPanel2.FillColor = System.Drawing.Color.Tan;
            this.guna2GradientPanel2.FillColor2 = System.Drawing.Color.BurlyWood;
            this.guna2GradientPanel2.Location = new System.Drawing.Point(70, 59);
            this.guna2GradientPanel2.Name = "guna2GradientPanel2";
            this.guna2GradientPanel2.Size = new System.Drawing.Size(317, 403);
            this.guna2GradientPanel2.TabIndex = 39;
            // 
            // sendToemailBtn
            // 
            this.sendToemailBtn.BackColor = System.Drawing.Color.Transparent;
            this.sendToemailBtn.BorderRadius = 18;
            this.sendToemailBtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.sendToemailBtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.sendToemailBtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.sendToemailBtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.sendToemailBtn.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.sendToemailBtn.Font = new System.Drawing.Font("Inter Black", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sendToemailBtn.ForeColor = System.Drawing.Color.White;
            this.sendToemailBtn.Location = new System.Drawing.Point(56, 308);
            this.sendToemailBtn.Name = "sendToemailBtn";
            this.sendToemailBtn.Size = new System.Drawing.Size(214, 45);
            this.sendToemailBtn.TabIndex = 36;
            this.sendToemailBtn.Text = "Send to Email";
            this.sendToemailBtn.Click += new System.EventHandler(this.sendToemailBtn_Click);
            // 
            // guna2HtmlLabel9
            // 
            this.guna2HtmlLabel9.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel9.Font = new System.Drawing.Font("Inter Black", 11.25F, System.Drawing.FontStyle.Bold);
            this.guna2HtmlLabel9.Location = new System.Drawing.Point(640, 273);
            this.guna2HtmlLabel9.Name = "guna2HtmlLabel9";
            this.guna2HtmlLabel9.Size = new System.Drawing.Size(119, 24);
            this.guna2HtmlLabel9.TabIndex = 38;
            this.guna2HtmlLabel9.Text = "Member Status";
            // 
            // guna2ControlBox1
            // 
            this.guna2ControlBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2ControlBox1.BackColor = System.Drawing.Color.Transparent;
            this.guna2ControlBox1.FillColor = System.Drawing.Color.Transparent;
            this.guna2ControlBox1.IconColor = System.Drawing.Color.Black;
            this.guna2ControlBox1.Location = new System.Drawing.Point(1060, 14);
            this.guna2ControlBox1.Name = "guna2ControlBox1";
            this.guna2ControlBox1.Size = new System.Drawing.Size(32, 23);
            this.guna2ControlBox1.TabIndex = 37;
            // 
            // guna2Elipse1
            // 
            this.guna2Elipse1.BorderRadius = 20;
            this.guna2Elipse1.TargetControl = this;
            // 
            // MemberInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Tan;
            this.ClientSize = new System.Drawing.Size(1106, 617);
            this.Controls.Add(this.guna2ControlBox1);
            this.Controls.Add(this.guna2GradientPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "MemberInfo";
            this.Padding = new System.Windows.Forms.Padding(40);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MemberInfo";
            ((System.ComponentModel.ISupportInitialize)(this.QRPictureBox)).EndInit();
            this.guna2GradientPanel1.ResumeLayout(false);
            this.guna2GradientPanel1.PerformLayout();
            this.guna2GradientPanel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox QRPictureBox;
        private Guna.UI2.WinForms.Guna2ContextMenuStrip guna2ContextMenuStrip1;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2Htmllabel;
        private Guna.UI2.WinForms.Guna2HtmlLabel lblFirstName;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2HtmlLabel lblLastName;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel3;
        private Guna.UI2.WinForms.Guna2HtmlLabel lblMiddleName;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel5;
        private Guna.UI2.WinForms.Guna2HtmlLabel lblMinistry;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel7;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel8;
        private Guna.UI2.WinForms.Guna2HtmlLabel lblUsername;
        private Guna.UI2.WinForms.Guna2HtmlLabel lblPosition;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel11;
        private Guna.UI2.WinForms.Guna2HtmlLabel lblContact;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel13;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel14;
        private Guna.UI2.WinForms.Guna2HtmlLabel lblEmail;
        private Guna.UI2.WinForms.Guna2HtmlLabel lblTransparochial;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel17;
        private Guna.UI2.WinForms.Guna2HtmlLabel lblAddress;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel2;
        private Guna.UI2.WinForms.Guna2HtmlLabel lblZone;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel6;
        private Guna.UI2.WinForms.Guna2HtmlLabel lblChapel;
        private Guna.UI2.WinForms.Guna2Button btnDownloadPDF;
        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel1;
        private Guna.UI2.WinForms.Guna2ControlBox guna2ControlBox1;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        private Guna.UI2.WinForms.Guna2Button sendToemailBtn;
        private Guna.UI2.WinForms.Guna2ComboBox comboStat;
        private Guna.UI2.WinForms.Guna2Button saveChanges;
        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel2;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel9;
    }
}