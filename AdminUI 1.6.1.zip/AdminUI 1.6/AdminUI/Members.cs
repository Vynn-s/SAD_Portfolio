﻿using FireSharp.Config;
using FireSharp.Interfaces;
using FireSharp.Response;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AdminUI.Models;

namespace AdminUI
{
    public partial class Members : Form
    {
        IFirebaseConfig config = new FirebaseConfig
        {
            AuthSecret = "mA771wfHHaDuyceGgGRt0Bf15LvkqN92pW4h6hbK",
            BasePath = "https://web-based-event-scheduling-default-rtdb.firebaseio.com/"
        };

        IFirebaseClient client;

        public Members()
        {
            InitializeComponent();
        }

        private string GetDayWithSuffix(int day)
        {
            if (day >= 11 && day <= 13)
                return day + "th";

            switch (day % 10)
            {
                case 1: return day + "st";
                case 2: return day + "nd";
                case 3: return day + "rd";
                default: return day + "th";
            }
        }

        private void Members_Load(object sender, EventArgs e)
        {
            timer1.Start();
            UpdateTimeAndDate();

            this.ControlBox = false;

            client = new FireSharp.FirebaseClient(config);
            LoadMemberList();
        }

        private void pendingBtn_Click(object sender, EventArgs e)
        {
            PendingMembers pendingForm = new PendingMembers();
            pendingForm.Show();
        }

        private void monthLabel_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            UpdateTimeAndDate();
        }

        private void UpdateTimeAndDate()
        {
            DateTime philippineTime = TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.UtcNow, "Singapore Standard Time");

            // Set formatted date on label
            string dayName = philippineTime.ToString("dddd");        // e.g., Friday
            string monthName = philippineTime.ToString("MMMM");      // e.g., May
            string dayWithSuffix = GetDayWithSuffix(philippineTime.Day); // e.g., 20th

            monthLabel.Text = $"{dayName}, {dayWithSuffix} {monthName}";
        }

        private void guna2Button3_Click(object sender, EventArgs e)
        {
            using (var form = new RegisterForm())
            {
                if (form.ShowDialog() == DialogResult.OK)
                {
                    LoadMemberList(); // ✅ Refresh the DataGridView after successful registration
                }
            }
        }

        public async void LoadMemberList()
        {
            try
            {
                FirebaseResponse response = await client.GetAsync("members");

                if (response.Body != "null")
                {
                    var membersDict = JsonConvert.DeserializeObject<Dictionary<string, MemberModel>>(response.Body);

                    var approvedMembers = membersDict
                        .Where(m => m.Value.Approved == true) // ✅ Only approved
                        .Select(m => new
                        {
                            ID = m.Value.MemberID,
                            FirstName = m.Value.FirstName,
                            MiddleName = m.Value.MiddleName,
                            LastName = m.Value.LastName,
                            Ministry = m.Value.Ministry,
                            Position = m.Value.Position,
                            Status = m.Value.MemberStatus ?? "none" // ✅ Add Status here
                        })
                        .ToList();

                    dataGridMembers.DataSource = approvedMembers;
                }
                else
                {
                    dataGridMembers.DataSource = null;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to load members: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private async void dataGridMembers_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // Reload
        }
        private async void btnSearch_Click(object sender, EventArgs e)
        {
            string searchText = txtSearch.Text.Trim().ToLower();

            if (string.IsNullOrEmpty(searchText))
            {
                LoadMemberList(); // Reload all if search box is empty
                return;
            }

            FirebaseResponse response = await client.GetAsync("members");
            if (response.Body != "null")
            {
                var membersDict = JsonConvert.DeserializeObject<Dictionary<string, MemberModel>>(response.Body);

                var filtered = membersDict
                    .Where(m =>
                        m.Value.Approved == true && (
                        (m.Value.FirstName + " " + m.Value.MiddleName + " " + m.Value.LastName).ToLower().Contains(searchText)
                        || (m.Value.FirstName + " " + m.Value.LastName).ToLower().Contains(searchText)
                        || m.Value.FirstName.ToLower().Contains(searchText)
                        || m.Value.LastName.ToLower().Contains(searchText)
                        || m.Value.MiddleName.ToLower().Contains(searchText))
                    )
                    .Select(m => new
                    {
                        ID = m.Value.MemberID,
                        FirstName = m.Value.FirstName,
                        MiddleName = m.Value.MiddleName,
                        LastName = m.Value.LastName,
                        Ministry = m.Value.Ministry,
                        Position = m.Value.Position,
                        Status = m.Value.MemberStatus ?? "none" // ✅ Add Status here
                    })
                    .ToList();

                dataGridMembers.DataSource = filtered;

            }
        }

        private async void deleteBtn_Click(object sender, EventArgs e)
        {
            if (dataGridMembers.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a member to delete.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Safely get selected MemberID
            var selectedRow = dataGridMembers.SelectedRows[0];
            string memberID = selectedRow.Cells["ID"].Value?.ToString();

            if (string.IsNullOrEmpty(memberID))
            {
                MessageBox.Show("Selected member ID is invalid.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Confirm with the user
            DialogResult confirm = MessageBox.Show(
                "This cannot be undone. Are you sure you want to delete this member?",
                "Confirm Deletion",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning);

            if (confirm == DialogResult.Yes)
            {
                FirebaseResponse response = await client.GetAsync("members");
                if (response.Body != "null")
                {
                    var membersDict = JsonConvert.DeserializeObject<Dictionary<string, MemberModel>>(response.Body);

                    // Match the member by MemberID
                    var match = membersDict.FirstOrDefault(m => m.Value.MemberID == memberID);

                    if (!string.IsNullOrEmpty(match.Key))
                    {
                        await client.DeleteAsync("members/" + match.Key);
                        MessageBox.Show("Member deleted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LoadMemberList(); // Refresh list
                    }
                    else
                    {
                        MessageBox.Show("Member not found in Firebase.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private async void viewBtn_Click(object sender, EventArgs e)
        {
            if (dataGridMembers.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a member to view details.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Get selected member ID from the DataGridView
            var selectedRow = dataGridMembers.SelectedRows[0];
            string memberID = selectedRow.Cells["ID"].Value?.ToString();

            if (string.IsNullOrEmpty(memberID))
            {
                MessageBox.Show("Selected member ID is invalid.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Retrieve full member details from Firebase
            FirebaseResponse response = await client.GetAsync("members");
            if (response.Body != "null")
            {
                var membersDict = JsonConvert.DeserializeObject<Dictionary<string, MemberModel>>(response.Body);
                var match = membersDict.FirstOrDefault(m => m.Value.MemberID == memberID);

                if (!string.IsNullOrEmpty(match.Key))
                {
                    MemberInfo memberForm = new MemberInfo();
                    memberForm.LoadMember(match.Key); // Pass Firebase key
                    memberForm.ShowDialog();
                }
                else
                {
                    MessageBox.Show("Member not found in Firebase.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {

        }

        private void refreshBtn_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Refreshing data...", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
            LoadMemberList();
        }
    }
}
