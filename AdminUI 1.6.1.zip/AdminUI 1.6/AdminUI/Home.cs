﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AdminUI.Models;


namespace AdminUI
{
    public partial class Home : Form
    {
        Dashboard dashboard;
        Members members;
        Events events;
        QRAttendance qRAttendance;
        About about;
        Chapels chapels;
        Settings settings;
        Calendar calendar;
        Announcement announcement;

        public Home(AdminModel admin)
        {
            InitializeComponent();
            loggedInAdmin = admin;
        }
        private AdminModel loggedInAdmin;

        private void dashboardBtn_Click(object sender, EventArgs e)
        {
            if (dashboard == null)
            {
                dashboard = new Dashboard(loggedInAdmin);
                dashboard.FormClosed += Dashboard_FormClosed;
                dashboard.MdiParent = this;
                dashboard.Dock = DockStyle.Fill;
                dashboard.Show();
            }
            else
            {
                dashboard.Activate();
            }
        }

        private void Dashboard_FormClosed(object sender, FormClosedEventArgs e)
        {
            dashboard = null;
        }

        private void membersBtn_Click(object sender, EventArgs e)
        {
            if (members == null)
            {
                members = new Members();
                members.FormClosed += Members_FormClosed;
                members.MdiParent = this;
                members.Dock = DockStyle.Fill;
                members.Show();
            }
            else
            {
                members.LoadMemberList(); // ✅ force refresh table
                members.Activate();
            }
        }


        private void Members_FormClosed(object sender, FormClosedEventArgs e)
        {
            members = null;
        }

        private void scannerBtn_Click(object sender, EventArgs e)
        {
            if (qRAttendance == null)
            {
                qRAttendance = new QRAttendance();
                qRAttendance.FormClosed += QRAttendance_FormClosed;
                qRAttendance.MdiParent = this;
                qRAttendance.Dock = DockStyle.Fill;
                qRAttendance.Show();
            }
            else
            {
                qRAttendance.Activate();
            }
        }

        private void QRAttendance_FormClosed(object sender, FormClosedEventArgs e)
        {
            qRAttendance = null;
        }

        private void eventsBtn_Click(object sender, EventArgs e)
        {
            if (events == null)
            {
                events = new Events(loggedInAdmin); // ✅ Pass admin
                events.FormClosed += Events_FormClosed;
                events.MdiParent = this;
                events.Dock = DockStyle.Fill;
                events.Show();
            }
            else
            {
                events.Activate();
            }
        }

        private void Events_FormClosed(object sender, FormClosedEventArgs e)
        {
            events = null;
        }

        private void guna2PictureBox1_LoadCompleted(object sender, AsyncCompletedEventArgs e)
        {

        }

        private void overviewBtn_Click(object sender, EventArgs e)
        {
            if (about == null)
            {
                about = new About();
                about.FormClosed += Overview_FormClosed;
                about.MdiParent = this;
                about.Dock = DockStyle.Fill;
                about.Show();
            }
            else
            {
                about.Activate();
            }
        }

        private void Overview_FormClosed(object sender, FormClosedEventArgs e)
        {
            about = null;
        }

        private void chapelBtn_Click(object sender, EventArgs e)
        {
            if (chapels == null)
            {
                chapels = new Chapels();
                chapels.FormClosed += Chapels_FormClosed;
                chapels.MdiParent = this;
                chapels.Dock = DockStyle.Fill;
                chapels.Show();
            }
            else
            {
                chapels.Activate();
            }
        }

        private void Chapels_FormClosed(object sender, FormClosedEventArgs e)
        {
            chapels = null;
        }

        private void settingsBtn_Click(object sender, EventArgs e)
        {
            if (settings == null)
            {
                settings = new Settings(loggedInAdmin, this); // Corrected line
                settings.FormClosed += Settings_FormClosed;
                settings.MdiParent = this;
                settings.Dock = DockStyle.Fill;
                settings.Show();
            }
            else
            {
                settings.Activate();
            }
        }



        private void Settings_FormClosed(object sender, FormClosedEventArgs e)
        {
            settings = null;
        }

        private void calendarBtn_Click(object sender, EventArgs e)
        {
            if (calendar == null)
            {
                calendar = new Calendar(loggedInAdmin);
                calendar.FormClosed += Calendar_FormClosed;
                calendar.MdiParent = this;
                calendar.Dock = DockStyle.Fill;
                calendar.Show();
            }
            else
            {
                calendar.Activate();
            }
        }

        private void Calendar_FormClosed(object sender, FormClosedEventArgs e)
        {
            calendar = null;
        }

        private void createBtn_Click(object sender, EventArgs e)
        {
            CreateEvent createEventForm = new CreateEvent(loggedInAdmin); // ✅ Pass admin
            createEventForm.Show();
        }

        private void timeBtn_Click(object sender, EventArgs e)
        {
            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            UpdateTimeButton();
        }

        private void Home_Load(object sender, EventArgs e)
        {
            timer1.Start();
            UpdateTimeButton();
        }
        private void UpdateTimeButton()
        {
            DateTime philippineTime = TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.UtcNow, "Singapore Standard Time");
            timeBtn.Text = philippineTime.ToString("h:mm tt", System.Globalization.CultureInfo.InvariantCulture).ToUpper();
        }

        private void announcementBtn_Click(object sender, EventArgs e)
        {
            if (announcement == null)
            {
                announcement = new Announcement(loggedInAdmin);
                announcement.FormClosed += Announcement_FormClosed;
                announcement.MdiParent = this;
                announcement.Dock = DockStyle.Fill;
                announcement.Show();
            }
            else
            {
                announcement.Activate();
            }
        }

        private void Announcement_FormClosed(object sender, FormClosedEventArgs e)
        {
            announcement = null;
        }
    }
}
