﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AdminUI
{
    public partial class LoadingDialog : Form
    {
        public LoadingDialog()
        {
            InitializeComponent();

            this.StartPosition = FormStartPosition.CenterScreen; // Center on screen
            this.ControlBox = false;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.Text = "Loading";
            this.Width = 280;
            this.Height = 100;

            Label loadingLabel = new Label();
            loadingLabel.Text = "Loading events, please wait...";
            loadingLabel.AutoSize = false;
            loadingLabel.TextAlign = ContentAlignment.MiddleCenter;
            loadingLabel.Dock = DockStyle.Fill;

            // Use Inter Bold — make sure "Inter" is installed on your system
            loadingLabel.Font = new Font("Inter", 10, FontStyle.Bold);

            this.Controls.Add(loadingLabel);
        }
    }
}
