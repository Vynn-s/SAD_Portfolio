﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FireSharp.Config;
using FireSharp.Interfaces;
using FireSharp.Response;
using Newtonsoft.Json;
using AdminUI.Models;


namespace AdminUI
{
    public partial class PendingMembers : Form
    {
        IFirebaseConfig config = new FirebaseConfig
        {
            AuthSecret = "mA771wfHHaDuyceGgGRt0Bf15LvkqN92pW4h6hbK",
            BasePath = "https://web-based-event-scheduling-default-rtdb.firebaseio.com/"
        };

        IFirebaseClient client;

        private Timer autoRefreshTimer;

        public PendingMembers()
        {
            InitializeComponent();
        }

        private async void PendingMembers_Load(object sender, EventArgs e)
        {
            client = new FireSharp.FirebaseClient(config);

            if (client == null)
            {
                MessageBox.Show("Could not connect to Firebase.");
                return;
            }

            await LoadPendingMembers();

            // Setup auto-refresh timer
            autoRefreshTimer = new Timer();
            autoRefreshTimer.Interval = 1000; 
            autoRefreshTimer.Tick += async (s, args) => await LoadPendingMembers();
            autoRefreshTimer.Start();
        }



        private async Task LoadPendingMembers()
        {
            try
            {
                FirebaseResponse response = await client.GetAsync("members");
                if (response.Body == "null")
                {
                    MessageBox.Show("No members found in Firebase.");
                    return;
                }

                var membersDict = JsonConvert.DeserializeObject<Dictionary<string, MemberModel>>(response.Body);

                foreach (var m in membersDict)
                {
                    Console.WriteLine($"[{m.Key}] {m.Value.FirstName} - Approved: {m.Value.Approved}");
                }

                var pendingMembers = membersDict
                    .Where(m => m.Value.Approved == false)
                    .Select(m => new
                    {
                        FirebaseKey = m.Key,
                        ID = m.Value.MemberID,
                        FirstName = m.Value.FirstName,
                        MiddleName = m.Value.MiddleName,
                        LastName = m.Value.LastName,
                        Ministry = m.Value.Ministry,
                        Position = m.Value.Position,
                        Chapel = m.Value.Chapel,
                        Zone = m.Value.Zone,
                        Email = m.Value.Email
                    })
                    .ToList();

                guna2DataGridView1.AutoGenerateColumns = true;
                guna2DataGridView1.DataSource = pendingMembers;

                // Hide FirebaseKey column
                if (guna2DataGridView1.Columns.Contains("FirebaseKey"))
                {
                    guna2DataGridView1.Columns["FirebaseKey"].Visible = false;
                }

                if (pendingMembers.Count == 0)
                {
                    MessageBox.Show("No pending members found.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading members: " + ex.Message);
            }
        }



        private void guna2ControlBox2_Click(object sender, EventArgs e)
        {

        }

        private void guna2ControlBox1_Click(object sender, EventArgs e)
        {

        }

        private async void approvedBtn_Click(object sender, EventArgs e)
        {
            if (guna2DataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a member to approve.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var selectedRow = guna2DataGridView1.SelectedRows[0];
            string memberKey = selectedRow.Cells["FirebaseKey"].Value?.ToString();

            if (string.IsNullOrEmpty(memberKey))
            {
                MessageBox.Show("Unable to find the selected member's key.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            DialogResult confirm = MessageBox.Show(
                "Are you sure this is an eligible member?",
                "Confirm Approval",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (confirm == DialogResult.Yes)
            {
                // Fetch existing data
                FirebaseResponse response = await client.GetAsync("members/" + memberKey);
                var member = JsonConvert.DeserializeObject<MemberModel>(response.Body);

                member.Approved = true;

                // Update to Firebase
                SetResponse updateResponse = await client.SetAsync("members/" + memberKey, member);

                MessageBox.Show("A new member is approved!!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                await LoadPendingMembers(); // Refresh list
            }
        }


        private void guna2DataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private async void refreshBtn_Click(object sender, EventArgs e)
        {
            if (client == null)
            {
                client = new FireSharp.FirebaseClient(config);

                if (client == null)
                {
                    MessageBox.Show("Could not connect to Firebase.");
                    return;
                }
            }

            await LoadPendingMembers();
        }
    }
}
