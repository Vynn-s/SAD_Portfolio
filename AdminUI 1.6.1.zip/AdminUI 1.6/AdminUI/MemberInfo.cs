﻿using FireSharp.Config;
using FireSharp.Interfaces;
using FireSharp.Response;
using Newtonsoft.Json;
using QRCoder;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using AdminUI.Models;
using PdfSharp.Pdf;
using PdfSharp.Drawing;
using System.Net;
using System.Net.Mail;

namespace AdminUI
{
    public partial class MemberInfo : Form
    {
        IFirebaseConfig config = new FirebaseConfig
        {
            AuthSecret = "mA771wfHHaDuyceGgGRt0Bf15LvkqN92pW4h6hbK",
            BasePath = "https://web-based-event-scheduling-default-rtdb.firebaseio.com/"
        };

        IFirebaseClient client;

        private string firebaseKey;

        public MemberInfo()
        {
            InitializeComponent();

            comboStat.Items.Clear();
            comboStat.Items.Add("none");
            comboStat.Items.Add("active");
            comboStat.Items.Add("dropped");
            comboStat.Items.Add("suspended");
        }

        public void LoadMember(string uid)
        {
            client = new FireSharp.FirebaseClient(config);
            firebaseKey = uid;
            DisplayMemberInfo(uid);
        }

        private void MemberInfo_Load(object sender, EventArgs e)
        {
            comboStat.Items.Clear();
            comboStat.Items.Add("none");
            comboStat.Items.Add("active");
            comboStat.Items.Add("dropped");
            comboStat.Items.Add("suspended");
            comboStat.SelectedIndex = 0;
        }

        private async void DisplayMemberInfo(string uid)
        {
            FirebaseResponse response = await client.GetAsync("members/" + uid);
            if (response.Body != "null")
            {
                var member = JsonConvert.DeserializeObject<MemberModel>(response.Body);

                lblFirstName.Text = member.FirstName;
                lblMiddleName.Text = member.MiddleName;
                lblLastName.Text = member.LastName;
                lblMinistry.Text = member.Ministry;
                lblPosition.Text = member.Position;
                lblUsername.Text = member.Username;
                lblContact.Text = member.ContactNumber;
                lblTransparochial.Text = member.Transparochial;
                lblEmail.Text = member.Email;
                lblAddress.Text = member.HomeAddress;
                lblZone.Text = member.Zone;
                lblChapel.Text = member.Chapel;

                // Load status into combo
                comboStat.SelectedItem = string.IsNullOrEmpty(member.MemberStatus) ? "none" : member.MemberStatus.ToLower();

                // QR Code
                QRCodeGenerator qrGenerator = new QRCodeGenerator();
                QRCodeData qrCodeData = qrGenerator.CreateQrCode("uid:" + uid, QRCodeGenerator.ECCLevel.Q);
                QRCode qrCode = new QRCode(qrCodeData);
                Bitmap qrImage = qrCode.GetGraphic(20);
                QRPictureBox.Image = qrImage;
            }
        }

        private async void saveChanges_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(firebaseKey))
            {
                MessageBox.Show("No member loaded.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string selectedStatus = comboStat.SelectedItem?.ToString() ?? "none";

            try
            {
                var updateObj = new Dictionary<string, object>
                {
                    { "MemberStatus", selectedStatus }
                };

                await client.UpdateAsync("members/" + firebaseKey, updateObj);

                MessageBox.Show("Status updated to '" + selectedStatus + "'.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Update failed:\n" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDownloadPDF_Click(object sender, EventArgs e)
        {
            try
            {
                PdfDocument document = new PdfDocument();
                document.Info.Title = "Member Profile";

                PdfPage page = document.AddPage();
                XGraphics gfx = XGraphics.FromPdfPage(page);

                XFont headerFont = new XFont("Arial", 14, XFontStyle.Bold);
                XFont subHeaderFont = new XFont("Arial", 10, XFontStyle.Regular);
                XFont titleFont = new XFont("Arial", 16, XFontStyle.Bold);
                XFont bodyFont = new XFont("Arial", 11, XFontStyle.Regular);
                XFont footerFont = new XFont("Arial", 8, XFontStyle.Italic);

                int pageWidth = (int)page.Width;
                int margin = 50;
                int y = 0;

                XSolidBrush blueBrush = new XSolidBrush(XColor.FromArgb(0, 70, 140));
                gfx.DrawRectangle(blueBrush, 0, y, page.Width, 60);

                gfx.DrawString("Sta. Ana Shrine Parish", headerFont, XBrushes.White, new XRect(0, y + 10, page.Width, 20), XStringFormats.TopCenter);
                gfx.DrawString("Sta. Ana Avenue, Davao City", subHeaderFont, XBrushes.White, new XRect(0, y + 30, page.Width, 20), XStringFormats.TopCenter);
                y += 80;

                gfx.DrawString("Member Profile", titleFont, XBrushes.Black, new XRect(0, y, page.Width, 30), XStringFormats.TopCenter);
                y += 40;

                XSolidBrush panelBrush = new XSolidBrush(XColors.LightGray);
                XRect panelRect = new XRect(margin, y, page.Width - 2 * margin, 220);
                gfx.DrawRoundedRectangle(panelBrush, panelRect, new XSize(10, 10));

                string fullName = $"{lblFirstName.Text} {lblMiddleName.Text} {lblLastName.Text}";
                int infoY = y + 20;
                int leftX = margin + 15;

                gfx.DrawString($"Name: {fullName}", bodyFont, XBrushes.Black, new XPoint(leftX, infoY += 20));
                gfx.DrawString($"Ministry: {lblMinistry.Text}", bodyFont, XBrushes.Black, new XPoint(leftX, infoY += 18));
                gfx.DrawString($"Position: {lblPosition.Text}", bodyFont, XBrushes.Black, new XPoint(leftX, infoY += 18));
                gfx.DrawString($"Chapel: {lblChapel.Text}", bodyFont, XBrushes.Black, new XPoint(leftX, infoY += 18));
                gfx.DrawString($"Zone: {lblZone.Text}", bodyFont, XBrushes.Black, new XPoint(leftX, infoY += 18));
                gfx.DrawString($"Email: {lblEmail.Text}", bodyFont, XBrushes.Black, new XPoint(leftX, infoY += 18));
                gfx.DrawString($"Contact: {lblContact.Text}", bodyFont, XBrushes.Black, new XPoint(leftX, infoY += 18));
                gfx.DrawString($"Address: {lblAddress.Text}", bodyFont, XBrushes.Black, new XPoint(leftX, infoY += 18));
                gfx.DrawString($"Transparochial: {lblTransparochial.Text}", bodyFont, XBrushes.Black, new XPoint(leftX, infoY += 18));
                gfx.DrawString($"Status: {comboStat.SelectedItem?.ToString()}", bodyFont, XBrushes.Black, new XPoint(leftX, infoY += 18));

                if (QRPictureBox.Image != null)
                {
                    string tempPath = Path.Combine(Path.GetTempPath(), "temp_qr.png");
                    QRPictureBox.Image.Save(tempPath, System.Drawing.Imaging.ImageFormat.Png);
                    XImage qrImg = XImage.FromFile(tempPath);

                    int qrSize = 120;
                    int qrX = pageWidth - margin - qrSize - 20;
                    int qrY = (int)panelRect.Top + 20;

                    gfx.DrawRectangle(XPens.Black, qrX - 3, qrY - 3, qrSize + 6, qrSize + 6);
                    gfx.DrawImage(qrImg, qrX, qrY, qrSize, qrSize);
                }

                gfx.DrawString($"Generated on: {DateTime.Now:MMMM dd, yyyy hh:mm tt}", footerFont, XBrushes.Gray, new XPoint(margin, page.Height - 40));

                SaveFileDialog saveDialog = new SaveFileDialog
                {
                    Filter = "PDF file (*.pdf)|*.pdf",
                    FileName = $"Member_{fullName.Replace(" ", "_")}.pdf"
                };

                if (saveDialog.ShowDialog() == DialogResult.OK)
                {
                    document.Save(saveDialog.FileName);
                    MessageBox.Show("PDF saved successfully.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("PDF error: " + ex.Message);
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            // Optional editing logic
        }

        private void comboStat_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Optional: live preview logic
        }

        private void sendToemailBtn_Click(object sender, EventArgs e)
        {
            try
            {
                string email = lblEmail.Text.Trim();
                string firstName = lblFirstName.Text.Trim();

                if (string.IsNullOrWhiteSpace(email))
                {
                    MessageBox.Show("Member email is missing.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                string tempFileName = $"QR_{Guid.NewGuid()}.png";
                string tempPath = Path.Combine(Path.GetTempPath(), tempFileName);
                QRPictureBox.Image.Save(tempPath, System.Drawing.Imaging.ImageFormat.Png);

                MailMessage mail = new MailMessage();
                mail.From = new MailAddress("infosphere333@gmail.com", "Sta. Ana Shrine Parish");
                mail.To.Add(email);
                mail.Subject = "Your Approved Account and QR Code – Sta. Ana Shrine Parish";
                mail.Body = $"Dear {firstName},\n\nAttached is your membership QR code. Please bring this to parish events.\n\nGod bless,\nSta. Ana Shrine Parish Team";

                Attachment qrAttachment = new Attachment(tempPath);
                mail.Attachments.Add(qrAttachment);

                SmtpClient smtp = new SmtpClient("smtp.gmail.com", 587)
                {
                    EnableSsl = true,
                    UseDefaultCredentials = false,
                    Credentials = new NetworkCredential("infosphere333@gmail.com", "rnxqwpqlcbyslkpt"),
                    DeliveryMethod = SmtpDeliveryMethod.Network,
                    Timeout = 20000
                };

                smtp.Send(mail);
                qrAttachment.Dispose();

                if (File.Exists(tempPath))
                    File.Delete(tempPath);

                MessageBox.Show("QR code sent to " + email, "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (SmtpException smtpEx)
            {
                MessageBox.Show("SMTP Error:\n" + smtpEx.Message, "SMTP Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unexpected Error:\n" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
