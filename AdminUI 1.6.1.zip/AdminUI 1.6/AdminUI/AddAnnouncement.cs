﻿using AdminUI.Models;
using FireSharp.Config;
using FireSharp.Interfaces;
using FireSharp.Response;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AdminUI
{
    public partial class AddAnnouncement : Form
    {
        IFirebaseConfig config = new FirebaseConfig
        {
            AuthSecret = "mA771wfHHaDuyceGgGRt0Bf15LvkqN92pW4h6hbK",
            BasePath = "https://web-based-event-scheduling-default-rtdb.firebaseio.com/"
        };

        IFirebaseClient client;

        private AdminModel _admin;

        public AddAnnouncement(AdminModel admin)
        {
            InitializeComponent();
            _admin = admin;

            client = new FireSharp.FirebaseClient(config);

            if (client == null)
            {
                MessageBox.Show("Firebase connection failed!");
            }
        }

        private void announcementName_TextChanged(object sender, EventArgs e)
        {

        }

        private void description_TextChanged(object sender, EventArgs e)
        {

        }

        private void reminders_TextChanged(object sender, EventArgs e)
        {

        }

        private void notes_TextChanged(object sender, EventArgs e)
        {

        }

        private async void addnewBtn_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(announcementName.Text) ||
                string.IsNullOrWhiteSpace(description.Text) ||
                string.IsNullOrWhiteSpace(reminders.Text) ||
                string.IsNullOrWhiteSpace(notes.Text))
            {
                MessageBox.Show("Please fill in all fields.");
                return;
            }

            string announcementId = Guid.NewGuid().ToString();
            string currentDate = DateTime.Now.ToString("yyyy-MM-dd");
            string currentTime = DateTime.Now.ToString("HH:mm:ss");

            var announcementData = new AnnouncementData
            {
                AnnouncementID = announcementId,
                AnnouncementName = announcementName.Text.Trim(),
                Description = description.Text.Trim(),
                Reminders = reminders.Text.Trim(),
                Notes = notes.Text.Trim(),
                DateCreated = currentDate,
                TimeCreated = currentTime,
                PublishedBy = _admin?.FullName ?? "Unknown" // <-- Use admin's full name
            };

            SetResponse response = await client.SetAsync("announcements/" + announcementId, announcementData);
            if (response.StatusCode == System.Net.HttpStatusCode.OK)
            {
                MessageBox.Show("Announcement created successfully!");
                this.Close();
            }
            else
            {
                MessageBox.Show("Failed to create announcement.");
            }
        }
    }
}
