﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FireSharp.Config;
using FireSharp.Interfaces;
using FireSharp.Response;
using System.Security.Cryptography;
using System.Net.Mail;



namespace AdminUI
{
    public partial class CreateAdmin : Form
    {
        IFirebaseConfig config = new FirebaseConfig
        {
            AuthSecret = "mA771wfHHaDuyceGgGRt0Bf15LvkqN92pW4h6hbK",
            BasePath = "https://web-based-event-scheduling-default-rtdb.firebaseio.com/"
        };

        IFirebaseClient client;
        public CreateAdmin()
        {
            InitializeComponent();
            InitializeFirebase();
        }
        private void InitializeFirebase()
        {
            try
            {
                client = new FireSharp.FirebaseClient(config);
                if (client == null)
                {
                    MessageBox.Show("Firebase client is null. Check your config.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Firebase connection failed.\n\nDetails:\n{ex.Message}");
            }
        }


        private bool IsValidEmail(string email)
        {
            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                return addr.Address == email;
            }
            catch
            {
                return false;
            }
        }


        private void CreateAdmin_Load(object sender, EventArgs e)
        {
            try
            {
                client = new FireSharp.FirebaseClient(config);
                if (client == null)
                {
                    MessageBox.Show("Firebase client is null. Check your config.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Firebase connection failed: " + ex.Message);
            }
        }

        private void fullName_TextChanged(object sender, EventArgs e)
        {

        }

        private void usernameAdmin_TextChanged(object sender, EventArgs e)
        {

        }

        private void emailAdmin_TextChanged(object sender, EventArgs e)
        {

        }

        private void passwordAdmin_TextChanged(object sender, EventArgs e)
        {

        }

        private void cancelBtn_Click(object sender, EventArgs e)
        {
            var confirmResult = MessageBox.Show("Are you sure you want to cancel?",
                                         "Confirm Cancel",
                                         MessageBoxButtons.YesNo);
            if (confirmResult == DialogResult.Yes)
            {
                this.Close(); // Closes the current form
            }
        }

        private async void submitBtn_Click(object sender, EventArgs e)
        {
            // Basic field validation
            if (string.IsNullOrWhiteSpace(fullName.Text) ||
                string.IsNullOrWhiteSpace(emailAdmin.Text) ||
                string.IsNullOrWhiteSpace(usernameAdmin.Text) ||
                string.IsNullOrWhiteSpace(passwordAdmin.Text))
            {
                MessageBox.Show("Please fill in all fields.");
                return;
            }

            // Email format validation
            if (!IsValidEmail(emailAdmin.Text))
            {
                MessageBox.Show("Please enter a valid email address.");
                return;
            }

            // Check Firebase connection
            if (client == null)
            {
                MessageBox.Show("Firebase client not initialized.");
                return;
            }

            try
            {
                // Check for existing username or email
                FirebaseResponse response = await client.GetAsync("admins");
                var data = response.ResultAs<Dictionary<string, AdminModel>>();

                bool usernameExists = data != null && data.Values.Any(a => a.adminUsername == usernameAdmin.Text);
                bool emailExists = data != null && data.Values.Any(a => a.adminEmail == emailAdmin.Text);

                if (usernameExists)
                {
                    MessageBox.Show("Username already exists.");
                    return;
                }

                if (emailExists)
                {
                    MessageBox.Show("Email already exists.");
                    return;
                }

                // All good, create admin
                string adminUID = Guid.NewGuid().ToString();
                var newAdmin = new AdminModel
                {
                    adminName = fullName.Text,
                    adminUsername = usernameAdmin.Text,
                    adminEmail = emailAdmin.Text,
                    adminPass = HashPassword(passwordAdmin.Text)
                };

                SetResponse setResponse = await client.SetAsync($"admins/{adminUID}", newAdmin);

                if (setResponse.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    MessageBox.Show("Admin created successfully.");
                    ClearFields();
                }
                else
                {
                    MessageBox.Show("Failed to create admin.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }


        private void ClearFields()
        {
            fullName.Text = "";
            emailAdmin.Text = "";
            usernameAdmin.Text = "";
            passwordAdmin.Text = "";
        }

        private string HashPassword(string password)
        {
            // SHA256 Hash (you can also use bcrypt or stronger methods)
            using (SHA256 sha256Hash = SHA256.Create())
            {
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder builder = new StringBuilder();
                foreach (byte b in bytes)
                    builder.Append(b.ToString("x2"));
                return builder.ToString();
            }
        }

        public class AdminModel
        {
            public string adminName { get; set; }
            public string adminUsername { get; set; }
            public string adminEmail { get; set; }
            public string adminPass { get; set; }
        }
    }
}
