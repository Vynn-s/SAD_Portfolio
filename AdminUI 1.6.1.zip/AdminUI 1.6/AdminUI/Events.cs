﻿using AdminUI.Models;
using FireSharp.Config;
using FireSharp.Interfaces;
using FireSharp.Response;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AdminUI
{
    public partial class Events : Form
    {
        IFirebaseConfig config = new FirebaseConfig
        {
            AuthSecret = "mA771wfHHaDuyceGgGRt0Bf15LvkqN92pW4h6hbK",
            BasePath = "https://web-based-event-scheduling-default-rtdb.firebaseio.com/"
        };

        IFirebaseClient client;

        private AdminModel _admin;

        public Events(AdminModel admin)
        {
            InitializeComponent();
            _admin = admin;
        }

        private void Events_Load(object sender, EventArgs e)
        {
            this.ControlBox = false;
            client = new FireSharp.FirebaseClient(config);

            if (client == null)
            {
                MessageBox.Show("Firebase connection failed!");
                return;
            }

            filtereventCombo.Items.Add("All Events");
            filtereventCombo.Items.Add("Today / Ongoing");
            filtereventCombo.Items.Add("Upcoming Events");
            filtereventCombo.SelectedIndex = -1;

            dataGridView1.Columns.Add("Published", "Published By");


            LoadEventData(); // Load all by default
        }

        private async void LoadEventData(string filter = "All")
        {
            LoadingDialog loading = new LoadingDialog();
            loading.Show();
            loading.Refresh();

            try
            {
                FirebaseResponse response = await client.GetAsync("events");
                dataGridView1.Rows.Clear();

                if (response.Body == "null")
                {
                    loading.Close();
                    MessageBox.Show("No events found for this filter.");
                    return;
                }

                Dictionary<string, EventData> events = JsonConvert.DeserializeObject<Dictionary<string, EventData>>(response.Body);

                List<EventData> filteredEvents = new List<EventData>();
                DateTime today = DateTime.Today;
                DateTime weekEnd = today.AddDays(7 - (int)today.DayOfWeek);
                DateTime monthEnd = new DateTime(today.Year, today.Month, DateTime.DaysInMonth(today.Year, today.Month));

                foreach (var ev in events.Values)
                {
                    if (DateTime.TryParse(ev.EventDate, out DateTime eventDate))
                    {
                        // Always skip past events
                        if (eventDate < today)
                            continue;

                        switch (filter)
                        {
                            case "Today / Ongoing":
                                if (eventDate == today)
                                    filteredEvents.Add(ev);
                                break;

                            case "Upcoming Events":
                                if (eventDate > today && eventDate.Year == today.Year)
                                    filteredEvents.Add(ev);
                                break;

                            default: // All Events
                                     // From today onward (this year or even future years)
                                if (eventDate >= today)
                                    filteredEvents.Add(ev);
                                break;
                        }
                    }
                }


                if (filteredEvents.Count == 0)
                {
                    loading.Close();
                    MessageBox.Show($"No events found for \"{filter}\".");
                    return;
                }

                foreach (var ev in filteredEvents.OrderBy(e => DateTime.Parse(e.EventDate)))
                {
                    dataGridView1.Rows.Add(ev.EventID, ev.EventName, ev.EventDate, ev.EventType, ev.EventTime, ev.EventVenue, ev.EventDescription, ev.Published);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading events: " + ex.Message);
            }
            finally
            {
                loading.Close();
            }
        }



        private void createBtn_Click(object sender, EventArgs e)
        {
            var createForm = new CreateEvent(_admin);
            createForm.FormClosed += (s, args) => LoadEventData(GetCurrentFilter());
            createForm.Show();
        }


        private void showBtn_Click(object sender, EventArgs e)
        {
            var prevForm = new PreviousEvents();
            prevForm.FormClosed += (s, args) => LoadEventData(GetCurrentFilter());
            prevForm.Show();
        }

        private void editBtn_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                // Get the selected event ID from the first column (assuming it's column 0)
                string eventId = dataGridView1.SelectedRows[0].Cells[0].Value?.ToString();

                if (!string.IsNullOrEmpty(eventId))
                {
                    var editForm = new EditEvent(_admin, eventId);
                    editForm.FormClosed += (s, args) => LoadEventData(GetCurrentFilter());
                    editForm.Show();
                }
                else
                {
                    MessageBox.Show("Unable to retrieve event ID from selected row.");
                }
            }
            else
            {
                MessageBox.Show("Please select an event to edit.");
            }
        }

        private void deleteBtn_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                string eventId = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();

                var result = MessageBox.Show("Are you sure you want to delete this event?", "Confirm Delete", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    client.Delete("events/" + eventId);
                    LoadEventData(); // Refresh after delete
                }
            }
            else
            {
                MessageBox.Show("Please select an event to delete.");
            }
        }

        private void filtereventCombo_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedFilter = filtereventCombo.SelectedItem?.ToString();
            LoadEventData(string.IsNullOrEmpty(selectedFilter) ? "All" : selectedFilter);
        }

        private string GetCurrentFilter()
        {
            return filtereventCombo.SelectedItem?.ToString() ?? "All";
        }

        private async void deleteBtn_Click_1(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                string eventId = dataGridView1.SelectedRows[0].Cells[0].Value?.ToString();

                if (string.IsNullOrEmpty(eventId))
                {
                    MessageBox.Show("Unable to retrieve event ID.");
                    return;
                }

                var confirm = MessageBox.Show(
                    "Are you sure you want to delete this event? This action cannot be undone.",
                    "Confirm Delete",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning
                );

                if (confirm == DialogResult.Yes)
                {
                    try
                    {
                        await client.DeleteAsync("events/" + eventId);
                        MessageBox.Show("Event deleted successfully.", "Deleted", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LoadEventData(GetCurrentFilter()); // Refresh list
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error deleting event: " + ex.Message);
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select an event to delete.");
            }
        }
    }
}
