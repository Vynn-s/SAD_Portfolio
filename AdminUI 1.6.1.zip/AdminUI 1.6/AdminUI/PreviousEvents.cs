﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using FireSharp.Config;
using FireSharp.Interfaces;
using FireSharp.Response;
using Newtonsoft.Json;
using PdfSharp.Drawing;
using PdfSharp.Pdf;
using System.IO;
using AdminUI.Models;
using System.Linq;
using Newtonsoft.Json.Linq;

namespace AdminUI
{
    public partial class PreviousEvents : Form
    {
        IFirebaseConfig config = new FirebaseConfig
        {
            AuthSecret = "mA771wfHHaDuyceGgGRt0Bf15LvkqN92pW4h6hbK",
            BasePath = "https://web-based-event-scheduling-default-rtdb.firebaseio.com/"
        };

        IFirebaseClient client;

        public PreviousEvents()
        {
            InitializeComponent();
            client = new FireSharp.FirebaseClient(config);
            LoadEvents();
            dataGridView1.CellDoubleClick += DataGridView1_CellDoubleClick;
            dataGridView1.Columns.Add("EventName", "Event Name");
            dataGridView1.Columns.Add("EventDate", "Date");
            dataGridView1.Columns.Add("EventType", "Type");
            dataGridView1.Columns.Add("EventTime", "Time");
            dataGridView1.Columns.Add("EventID", "Event ID");  // <-- This is your hidden column
            dataGridView1.Columns[4].Visible = false;          // <-- Hide the EventID column
        }

        private async void LoadEvents()
        {
            try
            {
                dataGridView1.Rows.Clear();
                FirebaseResponse response = await client.GetAsync("events");

                if (response.Body == "null") return;

                var events = JsonConvert.DeserializeObject<Dictionary<string, EventData>>(response.Body);

                foreach (var ev in events)
                {
                    // Skip events with incomplete dates
                    if (ev.Value.EventDate == null || ev.Value.EventDate.Length < 10)
                        continue;

                    if (DateTime.TryParse(ev.Value.EventDate, out DateTime eventDate)
                        && eventDate < DateTime.Today)
                    {
                        // Add bounds checking for columns
                        if (dataGridView1.Columns.Count >= 4) // Ensure columns exist
                        {
                            dataGridView1.Rows.Add(
                                ev.Value.EventName,
                                ev.Value.EventDate,
                                ev.Value.EventType,
                                ev.Value.EventTime,
                                ev.Key
                            );
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading events: {ex.Message}");
            }
        }


        private void DataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                // Check: Valid row index AND column 4 exists
                if (e.RowIndex >= 0 &&
                    e.RowIndex < dataGridView1.Rows.Count &&
                    dataGridView1.Columns.Count > 4 &&
                    !dataGridView1.Rows[e.RowIndex].IsNewRow)
                {
                    string eventId = dataGridView1.Rows[e.RowIndex].Cells[4].Value?.ToString();

                    if (!string.IsNullOrEmpty(eventId))
                    {
                        var eventHistory = new EventHistory(eventId);
                        eventHistory.Show();
                    }
                    else
                    {
                        MessageBox.Show("Event ID not found.", "Error",
                            MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error opening event: {ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }



        private void GeneratePdf(string filePath, EventData eventInfo, Dictionary<string, JToken> attendanceData)
        {
            using (PdfDocument doc = new PdfDocument())
            {
                PdfPage page = doc.AddPage();
                XGraphics gfx = XGraphics.FromPdfPage(page);
                XFont headerFont = new XFont("Arial", 14, XFontStyle.Bold);
                XFont bodyFont = new XFont("Arial", 10);

                int yPos = 40;

                // Event header
                gfx.DrawString($"{eventInfo.EventName} - Attendance Report", headerFont, XBrushes.Black,
                    new XRect(0, yPos, page.Width, page.Height), XStringFormats.TopCenter);
                yPos += 30;

                // Event details
                gfx.DrawString($"Date: {eventInfo.EventDate}", bodyFont, XBrushes.Black, 50, yPos);
                yPos += 20;
                gfx.DrawString($"Time: {eventInfo.EventTime}", bodyFont, XBrushes.Black, 50, yPos);
                yPos += 20;
                gfx.DrawString($"Type: {eventInfo.EventType}", bodyFont, XBrushes.Black, 50, yPos);
                yPos += 30;

                // Attendance table header
                gfx.DrawString("Name", bodyFont, XBrushes.Black, 50, yPos);
                gfx.DrawString("Time In", bodyFont, XBrushes.Black, 200, yPos);
                gfx.DrawString("Status", bodyFont, XBrushes.Black, 300, yPos);
                yPos += 20;

                // Attendance data
                foreach (var attendee in attendanceData.Values)
                {
                    if (yPos > page.Height - 50)
                    {
                        page = doc.AddPage();
                        gfx = XGraphics.FromPdfPage(page);
                        yPos = 40;
                    }

                    gfx.DrawString(attendee["Name"]?.ToString(), bodyFont, XBrushes.Black, 50, yPos);
                    gfx.DrawString(attendee["TimeIn"]?.ToString(), bodyFont, XBrushes.Black, 200, yPos);
                    gfx.DrawString(attendee["Status"]?.ToString(), bodyFont, XBrushes.Black, 300, yPos);
                    yPos += 15;
                }

                doc.Save(filePath);
            }
        }

        private async void Exportbtn_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow != null &&
                dataGridView1.CurrentRow.Index < dataGridView1.Rows.Count)
            {
                try
                {
                    Exportbtn.Enabled = false;
                    Cursor.Current = Cursors.WaitCursor;

                    // Get EventID from hidden column (index 4)
                    string eventId = dataGridView1.CurrentRow.Cells[4].Value?.ToString();

                    if (string.IsNullOrWhiteSpace(eventId))
                    {
                        MessageBox.Show("Invalid event selected.");
                        return;
                    }

                    // Get event details
                    FirebaseResponse eventResponse = await client.GetAsync($"events/{eventId}");
                    if (eventResponse.Body == "null")
                    {
                        MessageBox.Show("Event not found.");
                        return;
                    }

                    EventData eventInfo = JsonConvert.DeserializeObject<EventData>(eventResponse.Body);

                    // Get attendance data
                    FirebaseResponse attendanceResponse = await client.GetAsync($"attendances/{eventId}");
                    if (attendanceResponse.Body == "null")
                    {
                        MessageBox.Show("No attendance data to export.");
                        return;
                    }

                    var attendanceData = JObject.Parse(attendanceResponse.Body)
                        .Properties()
                        .Where(p => p.Name != "comment")
                        .ToDictionary(p => p.Name, p => p.Value);

                    // Save PDF
                    SaveFileDialog saveDialog = new SaveFileDialog
                    {
                        Filter = "PDF files (*.pdf)|*.pdf",
                        FileName = $"{eventInfo.EventName}_Attendance_{DateTime.Now:yyyyMMdd_HHmmss}.pdf"
                    };

                    if (saveDialog.ShowDialog() == DialogResult.OK)
                    {
                        GeneratePdf(saveDialog.FileName, eventInfo, attendanceData);
                        MessageBox.Show("PDF exported successfully!");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Export failed: " + ex.Message);
                }
                finally
                {
                    Exportbtn.Enabled = true;
                    Cursor.Current = Cursors.Default;
                }
            }
            else
            {
                MessageBox.Show("Please select an event to export.");
            }
        }
    }
}