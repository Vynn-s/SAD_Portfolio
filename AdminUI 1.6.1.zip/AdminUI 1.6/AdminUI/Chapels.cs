﻿using AdminUI.Models;
using FireSharp.Config;
using FireSharp.Interfaces;
using FireSharp.Response;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AdminUI
{
    public partial class Chapels : Form
    {
        IFirebaseConfig config = new FirebaseConfig
        {
            AuthSecret = "mA771wfHHaDuyceGgGRt0Bf15LvkqN92pW4h6hbK",
            BasePath = "https://web-based-event-scheduling-default-rtdb.firebaseio.com/"
        };

        IFirebaseClient client;

        private Dictionary<string, List<string>> zonesWithChapels = new Dictionary<string, List<string>>
        {
            { "Zone 1", new List<string> { "St. Anne Chapel", "Sistine Chapel", "Holy Spirit Chapel", "Our Lady of Sorrows Chapel", "St. Peter Chapel" } },
            { "Zone 2", new List<string> { "San Lorenzo Chapel", "St. Jude Chapel", "Divine Mercy Chapel", "Immaculate Conception Chapel", "St. Benedict Chapel" } },
            { "Zone 3", new List<string> { "Sta. Maria Chapel", "St. Joseph Chapel", "Christ the King Chapel", "San Sebastian Chapel", "Our Lady of Mt. Carmel Chapel" } },
            { "Zone 4", new List<string> { "St. Michael Chapel", "St. Augustine Chapel", "Mother of Perpetual Help Chapel", "Sacred Heart Chapel", "San Antonio Chapel" } },
            { "Zone 5", new List<string> { "Holy Cross Chapel", "St. Therese Chapel", "St. John the Baptist Chapel", "San Roque Chapel", "Our Lady of Guadalupe Chapel" } },
            { "Zone 6", new List<string> { "St. Dominic Chapel", "St. Paul Chapel", "St. Clare Chapel", "Our Lady of Fatima Chapel", "St. Ignatius Chapel" } },
            { "Zone 7", new List<string> { "St. Francis Chapel", "St. Andrew Chapel", "St. Cecilia Chapel", "St. Martin Chapel", "St. Matthew Chapel" } }
        };
        public Chapels()
        {
            InitializeComponent();
            zonecombo.Items.AddRange(zonesWithChapels.Keys.ToArray());
            client = new FireSharp.FirebaseClient(config);
        }

        private async Task LoadFilteredMembers()
        {
            FirebaseResponse response = await client.GetAsync("members");

            if (response.Body == "null") return;

            var membersData = JsonConvert.DeserializeObject<Dictionary<string, MemberModel>>(response.Body);

            // Only non-transparochial
            var members = membersData.Values
                .Where(m => !string.Equals(m.Transparochial, "yes", StringComparison.OrdinalIgnoreCase))
                .ToList();

            string selectedZone = zonecombo.SelectedItem?.ToString();
            string selectedChapel = chapelcombo.SelectedItem?.ToString();

            if (!string.IsNullOrEmpty(selectedZone))
                members = members.Where(m => m.Zone == selectedZone).ToList();

            if (!string.IsNullOrEmpty(selectedChapel))
                members = members.Where(m => m.Chapel == selectedChapel).ToList();

            var display = members.Select(m => new
            {
                FullName = $"{m.FirstName} {m.MiddleName} {m.LastName}",
                m.Position,
                m.Chapel,
                m.Zone,
                RegisteredAt = DateTime.TryParse(m.RegisteredAt, out var date) ? date.ToString("MMM dd, yyyy") : m.RegisteredAt
            }).ToList();

            datagridchapeszone.DataSource = display;

            if (display.Count == 0)
            {
                MessageBox.Show("No members found for this selection.", "Notice", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }


        private void Chapels_Load(object sender, EventArgs e)
        {
            this.ControlBox = false;
        }

        private void datagridchapeszone_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void chapelcombo_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedChapel = chapelcombo.SelectedItem?.ToString();
            LoadFilteredMembers(); // Filter by selected chapel too
        }


        private async void zonecombo_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedZone = zonecombo.SelectedItem?.ToString();

            if (!string.IsNullOrEmpty(selectedZone) && zonesWithChapels.ContainsKey(selectedZone))
            {
                chapelcombo.Items.Clear();
                chapelcombo.SelectedItem = null;
                chapelcombo.Items.AddRange(zonesWithChapels[selectedZone].ToArray());
            }

            await LoadFilteredMembers();
        }

        private void clearFilterBtn_Click(object sender, EventArgs e)
        {
            datagridchapeszone.DataSource = null;
        }

        private async void viewAllBtn_Click(object sender, EventArgs e)
        {
            FirebaseResponse response = await client.GetAsync("members");

            if (response.Body == "null") return;

            var membersData = JsonConvert.DeserializeObject<Dictionary<string, MemberModel>>(response.Body);

            var members = membersData.Values
                .Where(m => !string.Equals(m.Transparochial, "yes", StringComparison.OrdinalIgnoreCase))
                .OrderBy(m => m.Zone) // Alphabetical Zone sorting
                .ThenBy(m => m.Chapel)
                .ToList();

            var display = members.Select(m => new
            {
                FullName = $"{m.FirstName} {m.MiddleName} {m.LastName}",
                m.Position,
                m.Chapel,
                m.Zone,
                RegisteredAt = DateTime.TryParse(m.RegisteredAt, out var date) ? date.ToString("MMM dd, yyyy") : m.RegisteredAt
            }).ToList();

            datagridchapeszone.DataSource = display;
        }
    }
}
