﻿using FireSharp.Config;
using FireSharp.Interfaces;
using FireSharp.Response;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using QRCoder;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AdminUI.Models;

namespace AdminUI
{
    public partial class RegisterForm : Form
    {
        IFirebaseConfig config = new FirebaseConfig
        {
            AuthSecret = "mA771wfHHaDuyceGgGRt0Bf15LvkqN92pW4h6hbK",
            BasePath = "https://web-based-event-scheduling-default-rtdb.firebaseio.com/"
        };

        IFirebaseClient client;

        private static readonly string FirebaseApiKey = "AIzaSyC4YDw8dhp1qsJ7BhlNUSNHq3BxYzg6GDI";

        private Dictionary<string, List<string>> zoneChapelMap = new Dictionary<string, List<string>>();

        public RegisterForm()
        {
            InitializeComponent();
            client = new FireSharp.FirebaseClient(config);
            LoadDropdowns();
            ClearForm();
            comboZone.SelectedIndexChanged += ComboZone_SelectedIndexChanged;
            comboTransparochial.SelectedIndexChanged += ComboTransparochial_SelectedIndexChanged;
        }


        private void ComboTransparochial_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboTransparochial.SelectedItem?.ToString() == "Yes")
            {
                comboChapel.SelectedItem = "No Chapel";
                comboZone.SelectedItem = "No Zone";
                comboChapel.Enabled = false;
                comboZone.Enabled = false;
            }
            else
            {
                comboChapel.Enabled = true;
                comboZone.Enabled = true;
                comboChapel.SelectedIndex = -1;
                comboZone.SelectedIndex = -1;
            }
        }

        private void ComboZone_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedZone = comboZone.SelectedItem?.ToString();
            if (!string.IsNullOrEmpty(selectedZone) && zoneChapelMap.ContainsKey(selectedZone))
            {
                comboChapel.DataSource = null;
                comboChapel.Items.Clear();
                comboChapel.DataSource = zoneChapelMap[selectedZone];
                comboChapel.Enabled = true;
            }
            else
            {
                comboChapel.DataSource = null;
                comboChapel.Items.Clear();
                comboChapel.Enabled = false;
            }
        }

        private async void btnRegister_Click(object sender, EventArgs e)
        {
            try
            {
                string email = txtgmail.Text.Trim();
                string password = txtPassword.Text.Trim();

                if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
                {
                    MessageBox.Show("Email and password are required.");
                    return;
                }

                string uid = await RegisterWithEmailPassword(email, password);
                int nextID = await GetNextMemberID();
                string memberId = $"MEM-{nextID:D3}";

                var member = new MemberModel
                {
                    FirstName = txtFirstName.Text.Trim(),
                    LastName = txtLastName.Text.Trim(),
                    MiddleName = txtMiddleName.Text.Trim(),
                    ContactNumber = txtContact.Text.Trim(),
                    HomeAddress = txtAddress.Text.Trim(),
                    Transparochial = comboTransparochial.SelectedItem?.ToString(),
                    Ministry = comboMinistry.SelectedItem?.ToString(),
                    Chapel = comboChapel.SelectedItem?.ToString(),
                    Position = comboPosition.SelectedItem?.ToString(),
                    Zone = comboZone.SelectedItem?.ToString(),
                    Username = txtUsername.Text.Trim(),
                    Email = email,
                    MemberID = memberId,
                    RegisteredAt = DateTime.UtcNow.ToString("s") + "Z",
                    Role = "Member",
                    Approved = false,

                    MemberStatus = "none"
                };

                await client.SetAsync("members/" + uid, member);
                ShowQRCode(uid);
                MessageBox.Show("Registration complete. QR code generated.");
                this.DialogResult = DialogResult.OK; // ✅ Signal successful registration
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private async Task<string> RegisterWithEmailPassword(string email, string password)
        {
            using (var client = new HttpClient())
            {
                var payload = new
                {
                    email = email,
                    password = password,
                    returnSecureToken = true
                };

                var content = new StringContent(JsonConvert.SerializeObject(payload), Encoding.UTF8, "application/json");
                var response = await client.PostAsync($"https://identitytoolkit.googleapis.com/v1/accounts:signUp?key={FirebaseApiKey}", content);
                var result = await response.Content.ReadAsStringAsync();

                if (response.IsSuccessStatusCode)
                {
                    dynamic json = JsonConvert.DeserializeObject(result);
                    return json.localId;
                }
                else
                {
                    throw new Exception("Firebase Auth failed: " + result);
                }
            }
        }

        private async Task<int> GetNextMemberID()
        {
            FirebaseResponse response = await client.GetAsync("counters/memberCounter");
            int current = response.Body == "null" ? 0 : Convert.ToInt32(response.ResultAs<int>());
            int next = current + 1;
            await client.SetAsync("counters/memberCounter", next);
            return next;
        }

        public void ShowQRCode(string uid)
        {
            string qrData = "uid:" + uid;

            QRCodeGenerator qrGenerator = new QRCodeGenerator();
            QRCodeData qrCodeData = qrGenerator.CreateQrCode(qrData, QRCodeGenerator.ECCLevel.Q);
            QRCode qrCode = new QRCode(qrCodeData);
            Bitmap qrCodeImage = qrCode.GetGraphic(20);

            Form qrPopup = new Form();
            qrPopup.Text = "QR Code";
            qrPopup.Size = new Size(300, 300);

            PictureBox qrBox = new PictureBox();
            qrBox.Dock = DockStyle.Fill;
            qrBox.SizeMode = PictureBoxSizeMode.Zoom;
            qrBox.Image = qrCodeImage;

            qrPopup.Controls.Add(qrBox);
            qrPopup.ShowDialog();
        }

        private async void LoadDropdowns()
        {
            FirebaseResponse response = await client.GetAsync("dropdownOptions");
            if (response.Body != "null")
            {

                dynamic data = JsonConvert.DeserializeObject(response.Body);

                var chapelData = (JObject)data.zonesWithChapels;
                zoneChapelMap = chapelData.ToObject<Dictionary<string, List<string>>>();

                comboChapel.DataSource = ((JArray)data.chapels).ToObject<List<string>>();
                comboMinistry.DataSource = ((JArray)data.ministries).ToObject<List<string>>();
                comboPosition.DataSource = ((JArray)data.positions).ToObject<List<string>>();
                comboTransparochial.DataSource = ((JArray)data.transparochial).ToObject<List<string>>();
                comboZone.DataSource = ((JArray)data.zones).ToObject<List<string>>();

                comboChapel.SelectedIndex = -1;
                comboMinistry.SelectedIndex = -1;
                comboPosition.SelectedIndex = -1;
                comboTransparochial.SelectedIndex = -1;
                comboZone.SelectedIndex = -1;
            }
        }

        private void ClearForm()
        {
            txtFirstName.Clear();
            txtLastName.Clear();
            txtMiddleName.Clear();
            txtContact.Clear();
            txtAddress.Clear();
            txtUsername.Clear();
            txtgmail.Clear();
            txtPassword.Clear();

            comboChapel.Enabled = true;
            comboZone.Enabled = true;

            comboChapel.SelectedIndex = -1;
            comboMinistry.SelectedIndex = -1;
            comboPosition.SelectedIndex = -1;
            comboTransparochial.SelectedIndex = -1;
            comboZone.SelectedIndex = -1;
        }
    }

}