﻿using AdminUI.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AdminUI.Models;

namespace AdminUI
{
    public partial class ViewAnnouncement : Form
    {
        public ViewAnnouncement()
        {
            InitializeComponent();
        }

        public ViewAnnouncement(AdminUI.Models.AnnouncementData announcement) : this()
        {
            // Set field values
            announcementName.Text = announcement.AnnouncementName;
            Description.Text = announcement.Description;
            Reminders.Text = announcement.Reminders;
            notes.Text = announcement.Notes;
            date.Text = announcement.DateCreated;
            time.Text = announcement.TimeCreated;
            announcementID.Text = announcement.AnnouncementID; // ✅ Set the ID
        }
        private void announcementName_TextChanged(object sender, EventArgs e)
        {

        }

        private void Description_TextChanged(object sender, EventArgs e)
        {

        }

        private void Reminders_TextChanged(object sender, EventArgs e)
        {

        }

        private void notes_TextChanged(object sender, EventArgs e)
        {

        }

        private void date_Click(object sender, EventArgs e)
        {

        }

        private void time_Click(object sender, EventArgs e)
        {

        }

        private void announcementID_Click(object sender, EventArgs e)
        {

        }

        private void addnewBtn_Click(object sender, EventArgs e)
        {

        }
    }
}
