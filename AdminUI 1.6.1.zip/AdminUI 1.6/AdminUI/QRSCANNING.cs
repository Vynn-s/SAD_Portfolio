﻿using AForge.Video;
using AForge.Video.DirectShow;
using FireSharp.Config;
using FireSharp.Interfaces;
using FireSharp.Response;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Threading.Tasks;
using System.Windows.Forms;
using ZXing;
using AdminUI.Models;

namespace AdminUI
{
    public partial class QRSCANNING : Form
    {
        public Action OnAttendanceSaved;
        private FilterInfoCollection videoDevices;
        private VideoCaptureDevice videoSource;
        private ZXing.BarcodeReader reader;
        private bool isProcessing = false;
        private bool isScanning = false;

        IFirebaseConfig config = new FirebaseConfig
        {
            AuthSecret = "mA771wfHHaDuyceGgGRt0Bf15LvkqN92pW4h6hbK",
            BasePath = "https://web-based-event-scheduling-default-rtdb.firebaseio.com/"
        };
        IFirebaseClient client;

        public string EventId { get; set; }

        public QRSCANNING(string eventId)
        {
            InitializeComponent();
            EventId = eventId;

            this.Load += QRSCANNING_Load;
            this.FormClosing += QRSCANNING_FormClosing;

            client = new FireSharp.FirebaseClient(config);

            reader = new ZXing.BarcodeReader
            {
                AutoRotate = true,
                Options = new ZXing.Common.DecodingOptions
                {
                    TryHarder = true,
                    PossibleFormats = new List<BarcodeFormat> { BarcodeFormat.QR_CODE }
                }
            };
        }

        private async void QRSCANNING_Load(object sender, EventArgs e)
        {
            await Task.Delay(500); // Let form and labels initialize
            StartCamera();
        }


        private void StartCamera()
        {
            videoDevices = new FilterInfoCollection(FilterCategory.VideoInputDevice);

            if (videoDevices.Count == 0)
            {
                MessageBox.Show("No camera devices found.");
                return;
            }

            videoSource = new VideoCaptureDevice(videoDevices[0].MonikerString);
            videoSource.NewFrame += VideoSource_NewFrame;
            videoSource.Start();
        }

        private void VideoSource_NewFrame(object sender, NewFrameEventArgs eventArgs)
        {
            try
            {
                if (isScanning) return;

                Bitmap bitmap = (Bitmap)eventArgs.Frame.Clone();
                var result = reader.Decode(bitmap);

                if (result != null)
                {
                    isScanning = true;
                    string qrText = result.Text;

                    if (this.IsHandleCreated)
                    {
                        this.Invoke(new MethodInvoker(async () =>
                        {
                            if (QRBox.Image != null)
                                QRBox.Image.Dispose();

                            QRBox.Image = (Bitmap)bitmap.Clone();

                            await ProcessScannedData(qrText);
                            isScanning = false;
                        }));
                    }
                }
                else
                {
                    if (this.IsHandleCreated)
                    {
                        this.Invoke(new MethodInvoker(() =>
                        {
                            if (QRBox.Image != null)
                                QRBox.Image.Dispose();

                            QRBox.Image = (Bitmap)bitmap.Clone();
                        }));
                    }
                }

                bitmap.Dispose();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error in frame: " + ex.Message);
            }
        }

        private async Task ProcessScannedData(string scannedId)
        {
            try
            {
                scannedId = scannedId.Trim().Replace("uid:", "").Trim();

                // Try direct UID match
                FirebaseResponse response = await client.GetAsync("members/" + scannedId);
                if (response.Body != "null")
                {
                    MemberModel userData = JsonConvert.DeserializeObject<MemberModel>(response.Body);
                    await SaveAttendance(EventId, scannedId, userData);
                    OnAttendanceSaved?.Invoke();
                    await Task.Delay(5000);
                    ResetLabels();
                    return;
                }

                // Try matching by MemberID field
                FirebaseResponse allMembers = await client.GetAsync("members");
                if (allMembers.Body != "null")
                {
                    var membersDict = JsonConvert.DeserializeObject<Dictionary<string, MemberModel>>(allMembers.Body);

                    foreach (var member in membersDict)
                    {
                        if (!string.IsNullOrEmpty(member.Value.MemberID) &&
                            member.Value.MemberID.Trim().Equals(scannedId, StringComparison.OrdinalIgnoreCase))
                        {
                            await SaveAttendance(EventId, member.Key, member.Value);
                            OnAttendanceSaved?.Invoke();
                            await Task.Delay(5000);
                            ResetLabels();
                            return;
                        }
                    }
                }

                MessageBox.Show("Scanned ID not found.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }


        private string GetSafeValue(dynamic data, string propertyName)
        {
            try
            {
                var dict = (IDictionary<string, object>)data;

                foreach (var kv in dict)
                {
                    if (string.Equals(kv.Key, propertyName, StringComparison.OrdinalIgnoreCase))
                        return kv.Value?.ToString() ?? "-";
                }

                return "-";
            }
            catch
            {
                return "-";
            }
        }




        private void UpdateLabels(dynamic userData)
        {
            if (lblName.IsHandleCreated)
                lblName.Invoke((MethodInvoker)(() => lblName.Text = $"{userData.FirstName ?? "-"} {userData.LastName ?? "-"}"));
            if (lblMinistry.IsHandleCreated)
                lblMinistry.Invoke((MethodInvoker)(() => lblMinistry.Text = userData.ministry ?? "-"));
            if (lblZone.IsHandleCreated)
                lblZone.Invoke((MethodInvoker)(() => lblZone.Text = userData.zone ?? "-"));
            if (lblChapel.IsHandleCreated)
                lblChapel.Invoke((MethodInvoker)(() => lblChapel.Text = userData.chapel ?? "-"));
            if (lblStatus.IsHandleCreated)
                lblStatus.Invoke((MethodInvoker)(() => lblStatus.Text = "Present"));
        }



        private async Task SaveAttendance(string eventId, string userId, MemberModel userData)
        {
            string timestamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

            // Extract fields with fallback if null or empty
            string firstName = !string.IsNullOrEmpty(userData.FirstName) ? userData.FirstName : "-";
            string lastName = !string.IsNullOrEmpty(userData.LastName) ? userData.LastName : "-";
            string ministry = !string.IsNullOrEmpty(userData.Ministry) ? userData.Ministry : "-";
            string zone = !string.IsNullOrEmpty(userData.Zone) ? userData.Zone : "-";
            string chapel = !string.IsNullOrEmpty(userData.Chapel) ? userData.Chapel : "-";

            var attendance = new Attendance
            {
                Name = $"{firstName} {lastName}",
                Status = "Present",
                TimeIn = timestamp,
                Remarks = "✔ Checked In",
                Ministry = ministry,
                Zone = zone,
                Chapel = chapel,
                EventUid = eventId,
                MemberUid = userId,
                Comment = "No comment"
            };

            await client.SetAsync($"attendances/{eventId}/{userId}", attendance);

            // UI updates
            if (lblName.IsHandleCreated)
                lblName.Invoke((MethodInvoker)(() => lblName.Text = $"{firstName} {lastName}"));
            if (lblMinistry.IsHandleCreated)
                lblMinistry.Invoke((MethodInvoker)(() => lblMinistry.Text = ministry));
            if (lblZone.IsHandleCreated)
                lblZone.Invoke((MethodInvoker)(() => lblZone.Text = zone));
            if (lblChapel.IsHandleCreated)
                lblChapel.Invoke((MethodInvoker)(() => lblChapel.Text = chapel));
            if (lblStatus.IsHandleCreated)
                lblStatus.Invoke((MethodInvoker)(() => lblStatus.Text = "Present"));
        }



        // ✅ NEW METHOD: Case-insensitive field getter from dynamic Firebase data
        private string GetField(dynamic data, string fieldName)
        {
            try
            {
                var dict = JsonConvert.DeserializeObject<Dictionary<string, object>>(JsonConvert.SerializeObject(data));
                foreach (var kvp in dict)
                {
                    if (string.Equals(kvp.Key, fieldName, StringComparison.OrdinalIgnoreCase))
                    {
                        return kvp.Value?.ToString() ?? "-";
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("GetField error: " + ex.Message);
            }

            return "-";
        }



        private void ResetLabels()
        {
            if (lblName.IsHandleCreated)
                lblName.Invoke((MethodInvoker)(() => lblName.Text = "-"));
            if (lblMinistry.IsHandleCreated)
                lblMinistry.Invoke((MethodInvoker)(() => lblMinistry.Text = "-"));
            if (lblZone.IsHandleCreated)
                lblZone.Invoke((MethodInvoker)(() => lblZone.Text = "-"));
            if (lblChapel.IsHandleCreated)
                lblChapel.Invoke((MethodInvoker)(() => lblChapel.Text = "-"));
            if (lblStatus.IsHandleCreated)
                lblStatus.Invoke((MethodInvoker)(() => lblStatus.Text = "-"));
        }


        private void btnStopScanning_Click(object sender, EventArgs e)
        {
            if (videoSource != null && videoSource.IsRunning)
            {
                videoSource.SignalToStop();
                videoSource.NewFrame -= VideoSource_NewFrame;
                videoSource = null;
            }

            this.Close();
        }

        private void QRSCANNING_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (videoSource != null && videoSource.IsRunning)
            {
                videoSource.SignalToStop();
                videoSource.NewFrame -= VideoSource_NewFrame;
                videoSource = null;
            }
        }
    }
}
