﻿namespace AdminUI
{
    partial class Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            this.guna2BorderlessForm1 = new Guna.UI2.WinForms.Guna2BorderlessForm(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.guna2GradientPanel1 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.guna2GradientPanel8 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.datagridnewAnnouncement = new Guna.UI2.WinForms.Guna2DataGridView();
            this.guna2PictureBox2 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2HtmlLabel11 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2GradientPanel7 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.AllMembersBtn = new Guna.UI2.WinForms.Guna2Button();
            this.datagridRecentMem = new Guna.UI2.WinForms.Guna2DataGridView();
            this.guna2HtmlLabel10 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.AllEventsBtn = new Guna.UI2.WinForms.Guna2Button();
            this.datagridEvents = new Guna.UI2.WinForms.Guna2DataGridView();
            this.guna2HtmlLabel9 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2GradientPanel2 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.guna2GradientPanel5 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.announcementBtn = new Guna.UI2.WinForms.Guna2Button();
            this.guna2HtmlLabel7 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.announcementCount = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2GradientPanel6 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.pendingBtn = new Guna.UI2.WinForms.Guna2Button();
            this.guna2HtmlLabel5 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.pendingmemCount = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2GradientPanel4 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.eventsBtn = new Guna.UI2.WinForms.Guna2Button();
            this.guna2HtmlLabel3 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.eventscount = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2GradientPanel3 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.membersBtn = new Guna.UI2.WinForms.Guna2Button();
            this.guna2HtmlLabel2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.membersCount = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2Elipse2 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.panel1.SuspendLayout();
            this.guna2GradientPanel1.SuspendLayout();
            this.guna2GradientPanel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datagridnewAnnouncement)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox2)).BeginInit();
            this.guna2GradientPanel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datagridRecentMem)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.datagridEvents)).BeginInit();
            this.guna2GradientPanel2.SuspendLayout();
            this.guna2GradientPanel5.SuspendLayout();
            this.guna2GradientPanel6.SuspendLayout();
            this.guna2GradientPanel4.SuspendLayout();
            this.guna2GradientPanel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // guna2BorderlessForm1
            // 
            this.guna2BorderlessForm1.ContainerControl = this;
            this.guna2BorderlessForm1.DockIndicatorTransparencyValue = 0.6D;
            this.guna2BorderlessForm1.TransparentWhileDrag = true;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.panel1.Controls.Add(this.guna2GradientPanel1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Padding = new System.Windows.Forms.Padding(20);
            this.panel1.Size = new System.Drawing.Size(1721, 791);
            this.panel1.TabIndex = 0;
            // 
            // guna2GradientPanel1
            // 
            this.guna2GradientPanel1.Controls.Add(this.guna2GradientPanel8);
            this.guna2GradientPanel1.Controls.Add(this.guna2GradientPanel7);
            this.guna2GradientPanel1.Controls.Add(this.guna2GradientPanel2);
            this.guna2GradientPanel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.guna2GradientPanel1.Location = new System.Drawing.Point(20, 20);
            this.guna2GradientPanel1.Name = "guna2GradientPanel1";
            this.guna2GradientPanel1.Size = new System.Drawing.Size(1678, 751);
            this.guna2GradientPanel1.TabIndex = 2;
            // 
            // guna2GradientPanel8
            // 
            this.guna2GradientPanel8.Controls.Add(this.datagridnewAnnouncement);
            this.guna2GradientPanel8.Controls.Add(this.guna2PictureBox2);
            this.guna2GradientPanel8.Controls.Add(this.guna2HtmlLabel11);
            this.guna2GradientPanel8.Dock = System.Windows.Forms.DockStyle.Right;
            this.guna2GradientPanel8.Location = new System.Drawing.Point(848, 159);
            this.guna2GradientPanel8.Name = "guna2GradientPanel8";
            this.guna2GradientPanel8.Padding = new System.Windows.Forms.Padding(20);
            this.guna2GradientPanel8.Size = new System.Drawing.Size(830, 592);
            this.guna2GradientPanel8.TabIndex = 2;
            // 
            // datagridnewAnnouncement
            // 
            this.datagridnewAnnouncement.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Inter SemiBold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.White;
            this.datagridnewAnnouncement.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.datagridnewAnnouncement.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.datagridnewAnnouncement.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Inter", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.datagridnewAnnouncement.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.datagridnewAnnouncement.ColumnHeadersHeight = 40;
            this.datagridnewAnnouncement.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Inter Medium", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.datagridnewAnnouncement.DefaultCellStyle = dataGridViewCellStyle3;
            this.datagridnewAnnouncement.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.datagridnewAnnouncement.Location = new System.Drawing.Point(23, 73);
            this.datagridnewAnnouncement.Name = "datagridnewAnnouncement";
            this.datagridnewAnnouncement.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.datagridnewAnnouncement.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.datagridnewAnnouncement.RowHeadersVisible = false;
            this.datagridnewAnnouncement.RowTemplate.Height = 30;
            this.datagridnewAnnouncement.Size = new System.Drawing.Size(795, 492);
            this.datagridnewAnnouncement.TabIndex = 28;
            this.datagridnewAnnouncement.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.datagridnewAnnouncement.ThemeStyle.AlternatingRowsStyle.Font = new System.Drawing.Font("Inter SemiBold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datagridnewAnnouncement.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.SystemColors.ControlText;
            this.datagridnewAnnouncement.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Silver;
            this.datagridnewAnnouncement.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.White;
            this.datagridnewAnnouncement.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.datagridnewAnnouncement.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.datagridnewAnnouncement.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.datagridnewAnnouncement.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.datagridnewAnnouncement.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Inter", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datagridnewAnnouncement.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.datagridnewAnnouncement.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.datagridnewAnnouncement.ThemeStyle.HeaderStyle.Height = 40;
            this.datagridnewAnnouncement.ThemeStyle.ReadOnly = false;
            this.datagridnewAnnouncement.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.datagridnewAnnouncement.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.datagridnewAnnouncement.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Inter Medium", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datagridnewAnnouncement.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.datagridnewAnnouncement.ThemeStyle.RowsStyle.Height = 30;
            this.datagridnewAnnouncement.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.Silver;
            this.datagridnewAnnouncement.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.White;
            this.datagridnewAnnouncement.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.datagridnewAnnouncement_CellContentClick);
            // 
            // guna2PictureBox2
            // 
            this.guna2PictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox2.Image = global::AdminUI.Properties.Resources.output_onlinepngtools__5_;
            this.guna2PictureBox2.ImageRotate = 0F;
            this.guna2PictureBox2.Location = new System.Drawing.Point(239, 23);
            this.guna2PictureBox2.Name = "guna2PictureBox2";
            this.guna2PictureBox2.Size = new System.Drawing.Size(28, 26);
            this.guna2PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2PictureBox2.TabIndex = 27;
            this.guna2PictureBox2.TabStop = false;
            // 
            // guna2HtmlLabel11
            // 
            this.guna2HtmlLabel11.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel11.Font = new System.Drawing.Font("Inter Black", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.guna2HtmlLabel11.Location = new System.Drawing.Point(23, 21);
            this.guna2HtmlLabel11.Name = "guna2HtmlLabel11";
            this.guna2HtmlLabel11.Size = new System.Drawing.Size(210, 29);
            this.guna2HtmlLabel11.TabIndex = 16;
            this.guna2HtmlLabel11.Text = "New Announcements";
            // 
            // guna2GradientPanel7
            // 
            this.guna2GradientPanel7.Controls.Add(this.AllMembersBtn);
            this.guna2GradientPanel7.Controls.Add(this.datagridRecentMem);
            this.guna2GradientPanel7.Controls.Add(this.guna2HtmlLabel10);
            this.guna2GradientPanel7.Controls.Add(this.AllEventsBtn);
            this.guna2GradientPanel7.Controls.Add(this.datagridEvents);
            this.guna2GradientPanel7.Controls.Add(this.guna2HtmlLabel9);
            this.guna2GradientPanel7.Dock = System.Windows.Forms.DockStyle.Left;
            this.guna2GradientPanel7.Location = new System.Drawing.Point(0, 159);
            this.guna2GradientPanel7.Name = "guna2GradientPanel7";
            this.guna2GradientPanel7.Size = new System.Drawing.Size(825, 592);
            this.guna2GradientPanel7.TabIndex = 1;
            // 
            // AllMembersBtn
            // 
            this.AllMembersBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.AllMembersBtn.BorderRadius = 17;
            this.AllMembersBtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.AllMembersBtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.AllMembersBtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.AllMembersBtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.AllMembersBtn.FillColor = System.Drawing.Color.Transparent;
            this.AllMembersBtn.Font = new System.Drawing.Font("Inter", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AllMembersBtn.ForeColor = System.Drawing.Color.DimGray;
            this.AllMembersBtn.Location = new System.Drawing.Point(632, 31);
            this.AllMembersBtn.Name = "AllMembersBtn";
            this.AllMembersBtn.Size = new System.Drawing.Size(181, 36);
            this.AllMembersBtn.TabIndex = 21;
            this.AllMembersBtn.Text = "See All Members";
            this.AllMembersBtn.Click += new System.EventHandler(this.AllMembersBtn_Click);
            // 
            // datagridRecentMem
            // 
            this.datagridRecentMem.AllowUserToResizeRows = false;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Inter SemiBold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.White;
            this.datagridRecentMem.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle5;
            this.datagridRecentMem.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.datagridRecentMem.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Inter", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.datagridRecentMem.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.datagridRecentMem.ColumnHeadersHeight = 40;
            this.datagridRecentMem.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Inter Medium", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.datagridRecentMem.DefaultCellStyle = dataGridViewCellStyle7;
            this.datagridRecentMem.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.datagridRecentMem.Location = new System.Drawing.Point(421, 73);
            this.datagridRecentMem.Name = "datagridRecentMem";
            this.datagridRecentMem.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.datagridRecentMem.RowHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.datagridRecentMem.RowHeadersVisible = false;
            this.datagridRecentMem.RowTemplate.Height = 30;
            this.datagridRecentMem.Size = new System.Drawing.Size(392, 492);
            this.datagridRecentMem.TabIndex = 22;
            this.datagridRecentMem.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.datagridRecentMem.ThemeStyle.AlternatingRowsStyle.Font = new System.Drawing.Font("Inter SemiBold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datagridRecentMem.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.SystemColors.ControlText;
            this.datagridRecentMem.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Silver;
            this.datagridRecentMem.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.White;
            this.datagridRecentMem.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.datagridRecentMem.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.datagridRecentMem.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.datagridRecentMem.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.datagridRecentMem.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Inter", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datagridRecentMem.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.datagridRecentMem.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.datagridRecentMem.ThemeStyle.HeaderStyle.Height = 40;
            this.datagridRecentMem.ThemeStyle.ReadOnly = false;
            this.datagridRecentMem.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.datagridRecentMem.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.datagridRecentMem.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Inter Medium", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datagridRecentMem.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.datagridRecentMem.ThemeStyle.RowsStyle.Height = 30;
            this.datagridRecentMem.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.Silver;
            this.datagridRecentMem.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.White;
            this.datagridRecentMem.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.datagridRecentMem_CellContentClick);
            // 
            // guna2HtmlLabel10
            // 
            this.guna2HtmlLabel10.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel10.Font = new System.Drawing.Font("Inter Black", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.guna2HtmlLabel10.Location = new System.Drawing.Point(421, 31);
            this.guna2HtmlLabel10.Name = "guna2HtmlLabel10";
            this.guna2HtmlLabel10.Size = new System.Drawing.Size(166, 29);
            this.guna2HtmlLabel10.TabIndex = 20;
            this.guna2HtmlLabel10.Text = "Recent Members";
            // 
            // AllEventsBtn
            // 
            this.AllEventsBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.AllEventsBtn.BorderRadius = 17;
            this.AllEventsBtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.AllEventsBtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.AllEventsBtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.AllEventsBtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.AllEventsBtn.FillColor = System.Drawing.Color.Transparent;
            this.AllEventsBtn.Font = new System.Drawing.Font("Inter", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AllEventsBtn.ForeColor = System.Drawing.Color.DimGray;
            this.AllEventsBtn.Location = new System.Drawing.Point(217, 31);
            this.AllEventsBtn.Name = "AllEventsBtn";
            this.AllEventsBtn.Size = new System.Drawing.Size(181, 36);
            this.AllEventsBtn.TabIndex = 19;
            this.AllEventsBtn.Text = "See All Events";
            this.AllEventsBtn.Click += new System.EventHandler(this.AllEventsBtn_Click);
            // 
            // datagridEvents
            // 
            this.datagridEvents.AllowUserToResizeRows = false;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Inter SemiBold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.Color.White;
            this.datagridEvents.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle9;
            this.datagridEvents.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.datagridEvents.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Inter", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle10.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.datagridEvents.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle10;
            this.datagridEvents.ColumnHeadersHeight = 40;
            this.datagridEvents.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Inter Medium", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.datagridEvents.DefaultCellStyle = dataGridViewCellStyle11;
            this.datagridEvents.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.datagridEvents.Location = new System.Drawing.Point(26, 73);
            this.datagridEvents.Name = "datagridEvents";
            this.datagridEvents.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.datagridEvents.RowHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.datagridEvents.RowHeadersVisible = false;
            this.datagridEvents.RowTemplate.Height = 30;
            this.datagridEvents.Size = new System.Drawing.Size(372, 492);
            this.datagridEvents.TabIndex = 16;
            this.datagridEvents.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.datagridEvents.ThemeStyle.AlternatingRowsStyle.Font = new System.Drawing.Font("Inter SemiBold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datagridEvents.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.SystemColors.ControlText;
            this.datagridEvents.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Silver;
            this.datagridEvents.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.White;
            this.datagridEvents.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.datagridEvents.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.datagridEvents.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.datagridEvents.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.datagridEvents.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Inter", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datagridEvents.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.datagridEvents.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.datagridEvents.ThemeStyle.HeaderStyle.Height = 40;
            this.datagridEvents.ThemeStyle.ReadOnly = false;
            this.datagridEvents.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.datagridEvents.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.datagridEvents.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Inter Medium", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datagridEvents.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.datagridEvents.ThemeStyle.RowsStyle.Height = 30;
            this.datagridEvents.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.Silver;
            this.datagridEvents.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.White;
            this.datagridEvents.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.datagridEvents_CellContentClick);
            // 
            // guna2HtmlLabel9
            // 
            this.guna2HtmlLabel9.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel9.Font = new System.Drawing.Font("Inter Black", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.guna2HtmlLabel9.Location = new System.Drawing.Point(26, 31);
            this.guna2HtmlLabel9.Name = "guna2HtmlLabel9";
            this.guna2HtmlLabel9.Size = new System.Drawing.Size(171, 29);
            this.guna2HtmlLabel9.TabIndex = 15;
            this.guna2HtmlLabel9.Text = "Upcoming Events";
            // 
            // guna2GradientPanel2
            // 
            this.guna2GradientPanel2.Controls.Add(this.guna2GradientPanel5);
            this.guna2GradientPanel2.Controls.Add(this.guna2GradientPanel6);
            this.guna2GradientPanel2.Controls.Add(this.guna2GradientPanel4);
            this.guna2GradientPanel2.Controls.Add(this.guna2GradientPanel3);
            this.guna2GradientPanel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.guna2GradientPanel2.Location = new System.Drawing.Point(0, 0);
            this.guna2GradientPanel2.Name = "guna2GradientPanel2";
            this.guna2GradientPanel2.Size = new System.Drawing.Size(1678, 159);
            this.guna2GradientPanel2.TabIndex = 0;
            // 
            // guna2GradientPanel5
            // 
            this.guna2GradientPanel5.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.guna2GradientPanel5.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientPanel5.BorderRadius = 24;
            this.guna2GradientPanel5.Controls.Add(this.announcementBtn);
            this.guna2GradientPanel5.Controls.Add(this.guna2HtmlLabel7);
            this.guna2GradientPanel5.Controls.Add(this.announcementCount);
            this.guna2GradientPanel5.FillColor = System.Drawing.Color.White;
            this.guna2GradientPanel5.FillColor2 = System.Drawing.Color.White;
            this.guna2GradientPanel5.Location = new System.Drawing.Point(1262, 13);
            this.guna2GradientPanel5.Name = "guna2GradientPanel5";
            this.guna2GradientPanel5.Padding = new System.Windows.Forms.Padding(20);
            this.guna2GradientPanel5.Size = new System.Drawing.Size(404, 134);
            this.guna2GradientPanel5.TabIndex = 14;
            // 
            // announcementBtn
            // 
            this.announcementBtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.announcementBtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.announcementBtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.announcementBtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.announcementBtn.FillColor = System.Drawing.Color.Transparent;
            this.announcementBtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.announcementBtn.ForeColor = System.Drawing.Color.White;
            this.announcementBtn.Image = global::AdminUI.Properties.Resources.output_onlinepngtools__1_;
            this.announcementBtn.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.announcementBtn.ImageSize = new System.Drawing.Size(55, 55);
            this.announcementBtn.Location = new System.Drawing.Point(235, 35);
            this.announcementBtn.Name = "announcementBtn";
            this.announcementBtn.Size = new System.Drawing.Size(146, 64);
            this.announcementBtn.TabIndex = 19;
            // 
            // guna2HtmlLabel7
            // 
            this.guna2HtmlLabel7.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel7.Font = new System.Drawing.Font("Inter", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel7.ForeColor = System.Drawing.Color.DarkGreen;
            this.guna2HtmlLabel7.Location = new System.Drawing.Point(23, 74);
            this.guna2HtmlLabel7.Name = "guna2HtmlLabel7";
            this.guna2HtmlLabel7.Size = new System.Drawing.Size(206, 25);
            this.guna2HtmlLabel7.TabIndex = 18;
            this.guna2HtmlLabel7.Text = "Announcement Published";
            // 
            // announcementCount
            // 
            this.announcementCount.BackColor = System.Drawing.Color.Transparent;
            this.announcementCount.Font = new System.Drawing.Font("Inter", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.announcementCount.ForeColor = System.Drawing.Color.DarkGreen;
            this.announcementCount.Location = new System.Drawing.Point(23, 25);
            this.announcementCount.Name = "announcementCount";
            this.announcementCount.Size = new System.Drawing.Size(28, 55);
            this.announcementCount.TabIndex = 17;
            this.announcementCount.Text = "0";
            this.announcementCount.Click += new System.EventHandler(this.announcementCount_Click);
            // 
            // guna2GradientPanel6
            // 
            this.guna2GradientPanel6.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.guna2GradientPanel6.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientPanel6.BorderRadius = 24;
            this.guna2GradientPanel6.Controls.Add(this.pendingBtn);
            this.guna2GradientPanel6.Controls.Add(this.guna2HtmlLabel5);
            this.guna2GradientPanel6.Controls.Add(this.pendingmemCount);
            this.guna2GradientPanel6.FillColor = System.Drawing.Color.White;
            this.guna2GradientPanel6.FillColor2 = System.Drawing.Color.White;
            this.guna2GradientPanel6.Location = new System.Drawing.Point(848, 13);
            this.guna2GradientPanel6.Name = "guna2GradientPanel6";
            this.guna2GradientPanel6.Padding = new System.Windows.Forms.Padding(20);
            this.guna2GradientPanel6.Size = new System.Drawing.Size(395, 134);
            this.guna2GradientPanel6.TabIndex = 13;
            // 
            // pendingBtn
            // 
            this.pendingBtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.pendingBtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.pendingBtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.pendingBtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.pendingBtn.FillColor = System.Drawing.Color.Transparent;
            this.pendingBtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.pendingBtn.ForeColor = System.Drawing.Color.White;
            this.pendingBtn.Image = global::AdminUI.Properties.Resources.output_onlinepngtools;
            this.pendingBtn.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.pendingBtn.ImageSize = new System.Drawing.Size(50, 50);
            this.pendingBtn.Location = new System.Drawing.Point(192, 35);
            this.pendingBtn.Name = "pendingBtn";
            this.pendingBtn.Size = new System.Drawing.Size(180, 64);
            this.pendingBtn.TabIndex = 17;
            this.pendingBtn.Click += new System.EventHandler(this.pendingBtn_Click);
            // 
            // guna2HtmlLabel5
            // 
            this.guna2HtmlLabel5.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel5.Font = new System.Drawing.Font("Inter", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel5.ForeColor = System.Drawing.Color.DarkGreen;
            this.guna2HtmlLabel5.Location = new System.Drawing.Point(23, 74);
            this.guna2HtmlLabel5.Name = "guna2HtmlLabel5";
            this.guna2HtmlLabel5.Size = new System.Drawing.Size(147, 25);
            this.guna2HtmlLabel5.TabIndex = 16;
            this.guna2HtmlLabel5.Text = "Pending Members";
            // 
            // pendingmemCount
            // 
            this.pendingmemCount.BackColor = System.Drawing.Color.Transparent;
            this.pendingmemCount.Font = new System.Drawing.Font("Inter", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pendingmemCount.ForeColor = System.Drawing.Color.DarkGreen;
            this.pendingmemCount.Location = new System.Drawing.Point(23, 25);
            this.pendingmemCount.Name = "pendingmemCount";
            this.pendingmemCount.Size = new System.Drawing.Size(28, 55);
            this.pendingmemCount.TabIndex = 15;
            this.pendingmemCount.Text = "0";
            this.pendingmemCount.Click += new System.EventHandler(this.pendingmemCount_Click);
            // 
            // guna2GradientPanel4
            // 
            this.guna2GradientPanel4.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientPanel4.BorderRadius = 24;
            this.guna2GradientPanel4.Controls.Add(this.eventsBtn);
            this.guna2GradientPanel4.Controls.Add(this.guna2HtmlLabel3);
            this.guna2GradientPanel4.Controls.Add(this.eventscount);
            this.guna2GradientPanel4.FillColor = System.Drawing.Color.White;
            this.guna2GradientPanel4.FillColor2 = System.Drawing.Color.White;
            this.guna2GradientPanel4.Location = new System.Drawing.Point(421, 13);
            this.guna2GradientPanel4.Name = "guna2GradientPanel4";
            this.guna2GradientPanel4.Padding = new System.Windows.Forms.Padding(20);
            this.guna2GradientPanel4.Size = new System.Drawing.Size(404, 134);
            this.guna2GradientPanel4.TabIndex = 12;
            // 
            // eventsBtn
            // 
            this.eventsBtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.eventsBtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.eventsBtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.eventsBtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.eventsBtn.FillColor = System.Drawing.Color.Transparent;
            this.eventsBtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.eventsBtn.ForeColor = System.Drawing.Color.White;
            this.eventsBtn.Image = global::AdminUI.Properties.Resources.output_onlinepngtools__3_;
            this.eventsBtn.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.eventsBtn.ImageSize = new System.Drawing.Size(50, 50);
            this.eventsBtn.Location = new System.Drawing.Point(201, 35);
            this.eventsBtn.Name = "eventsBtn";
            this.eventsBtn.Size = new System.Drawing.Size(180, 64);
            this.eventsBtn.TabIndex = 15;
            this.eventsBtn.Click += new System.EventHandler(this.eventsBtn_Click);
            // 
            // guna2HtmlLabel3
            // 
            this.guna2HtmlLabel3.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel3.Font = new System.Drawing.Font("Inter", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel3.ForeColor = System.Drawing.Color.DarkGreen;
            this.guna2HtmlLabel3.Location = new System.Drawing.Point(23, 74);
            this.guna2HtmlLabel3.Name = "guna2HtmlLabel3";
            this.guna2HtmlLabel3.Size = new System.Drawing.Size(58, 25);
            this.guna2HtmlLabel3.TabIndex = 14;
            this.guna2HtmlLabel3.Text = "Events";
            // 
            // eventscount
            // 
            this.eventscount.BackColor = System.Drawing.Color.Transparent;
            this.eventscount.Font = new System.Drawing.Font("Inter", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.eventscount.ForeColor = System.Drawing.Color.DarkGreen;
            this.eventscount.Location = new System.Drawing.Point(23, 25);
            this.eventscount.Name = "eventscount";
            this.eventscount.Size = new System.Drawing.Size(28, 55);
            this.eventscount.TabIndex = 13;
            this.eventscount.Text = "0";
            this.eventscount.Click += new System.EventHandler(this.eventscount_Click);
            // 
            // guna2GradientPanel3
            // 
            this.guna2GradientPanel3.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientPanel3.BorderRadius = 24;
            this.guna2GradientPanel3.Controls.Add(this.membersBtn);
            this.guna2GradientPanel3.Controls.Add(this.guna2HtmlLabel2);
            this.guna2GradientPanel3.Controls.Add(this.membersCount);
            this.guna2GradientPanel3.FillColor = System.Drawing.Color.White;
            this.guna2GradientPanel3.FillColor2 = System.Drawing.Color.White;
            this.guna2GradientPanel3.Location = new System.Drawing.Point(3, 13);
            this.guna2GradientPanel3.Name = "guna2GradientPanel3";
            this.guna2GradientPanel3.Padding = new System.Windows.Forms.Padding(20);
            this.guna2GradientPanel3.Size = new System.Drawing.Size(395, 134);
            this.guna2GradientPanel3.TabIndex = 11;
            // 
            // membersBtn
            // 
            this.membersBtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.membersBtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.membersBtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.membersBtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.membersBtn.FillColor = System.Drawing.Color.Transparent;
            this.membersBtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.membersBtn.ForeColor = System.Drawing.Color.White;
            this.membersBtn.Image = global::AdminUI.Properties.Resources.output_onlinepngtools__2_;
            this.membersBtn.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.membersBtn.ImageSize = new System.Drawing.Size(70, 70);
            this.membersBtn.Location = new System.Drawing.Point(192, 35);
            this.membersBtn.Name = "membersBtn";
            this.membersBtn.PressedColor = System.Drawing.Color.WhiteSmoke;
            this.membersBtn.Size = new System.Drawing.Size(180, 64);
            this.membersBtn.TabIndex = 13;
            this.membersBtn.Click += new System.EventHandler(this.membersBtn_Click);
            // 
            // guna2HtmlLabel2
            // 
            this.guna2HtmlLabel2.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel2.Font = new System.Drawing.Font("Inter", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel2.ForeColor = System.Drawing.Color.DarkGreen;
            this.guna2HtmlLabel2.Location = new System.Drawing.Point(23, 74);
            this.guna2HtmlLabel2.Name = "guna2HtmlLabel2";
            this.guna2HtmlLabel2.Size = new System.Drawing.Size(79, 25);
            this.guna2HtmlLabel2.TabIndex = 12;
            this.guna2HtmlLabel2.Text = "Members";
            // 
            // membersCount
            // 
            this.membersCount.BackColor = System.Drawing.Color.Transparent;
            this.membersCount.Font = new System.Drawing.Font("Inter", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.membersCount.ForeColor = System.Drawing.Color.DarkGreen;
            this.membersCount.Location = new System.Drawing.Point(23, 25);
            this.membersCount.Name = "membersCount";
            this.membersCount.Size = new System.Drawing.Size(28, 55);
            this.membersCount.TabIndex = 11;
            this.membersCount.Text = "0";
            this.membersCount.Click += new System.EventHandler(this.membersCount_Click);
            // 
            // guna2Elipse1
            // 
            this.guna2Elipse1.BorderRadius = 15;
            this.guna2Elipse1.TargetControl = this.datagridEvents;
            // 
            // guna2Elipse2
            // 
            this.guna2Elipse2.BorderRadius = 15;
            this.guna2Elipse2.TargetControl = this.datagridRecentMem;
            // 
            // Dashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1721, 791);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Dashboard";
            this.Text = "Dashboard";
            this.Load += new System.EventHandler(this.Dashboard_Load);
            this.panel1.ResumeLayout(false);
            this.guna2GradientPanel1.ResumeLayout(false);
            this.guna2GradientPanel8.ResumeLayout(false);
            this.guna2GradientPanel8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datagridnewAnnouncement)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox2)).EndInit();
            this.guna2GradientPanel7.ResumeLayout(false);
            this.guna2GradientPanel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datagridRecentMem)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.datagridEvents)).EndInit();
            this.guna2GradientPanel2.ResumeLayout(false);
            this.guna2GradientPanel5.ResumeLayout(false);
            this.guna2GradientPanel5.PerformLayout();
            this.guna2GradientPanel6.ResumeLayout(false);
            this.guna2GradientPanel6.PerformLayout();
            this.guna2GradientPanel4.ResumeLayout(false);
            this.guna2GradientPanel4.PerformLayout();
            this.guna2GradientPanel3.ResumeLayout(false);
            this.guna2GradientPanel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2BorderlessForm guna2BorderlessForm1;
        private System.Windows.Forms.Panel panel1;
        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel1;
        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel2;
        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel5;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel7;
        private Guna.UI2.WinForms.Guna2HtmlLabel announcementCount;
        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel6;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel5;
        private Guna.UI2.WinForms.Guna2HtmlLabel pendingmemCount;
        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel4;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel3;
        private Guna.UI2.WinForms.Guna2HtmlLabel eventscount;
        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel3;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel2;
        private Guna.UI2.WinForms.Guna2HtmlLabel membersCount;
        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel8;
        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel7;
        private Guna.UI2.WinForms.Guna2DataGridView datagridEvents;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel9;
        private Guna.UI2.WinForms.Guna2Button AllEventsBtn;
        private Guna.UI2.WinForms.Guna2DataGridViewStyler guna2DataGridViewStyler1;
        private Guna.UI2.WinForms.Guna2DataGridView datagridRecentMem;
        private Guna.UI2.WinForms.Guna2Button membersBtn;
        private Guna.UI2.WinForms.Guna2Button announcementBtn;
        private Guna.UI2.WinForms.Guna2Button pendingBtn;
        private Guna.UI2.WinForms.Guna2Button eventsBtn;
        private Guna.UI2.WinForms.Guna2Button AllMembersBtn;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel10;
        private Guna.UI2.WinForms.Guna2DataGridViewStyler guna2DataGridViewStyler2;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel11;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse2;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox2;
        private Guna.UI2.WinForms.Guna2DataGridView datagridnewAnnouncement;
    }
}