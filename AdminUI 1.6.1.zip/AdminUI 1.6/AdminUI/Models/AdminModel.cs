﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdminUI.Models
{
    public class AdminModel
    {
        public string adminName { get; set; }
        public string adminUsername { get; set; }
        public string adminEmail { get; set; }
        public string adminPass { get; set; }
        public string FullName => adminName;


        // Optional: constructor for convenience
        public AdminModel() { }

        public AdminModel(string name, string username, string email, string pass)
        {
            adminName = name;
            adminUsername = username;
            adminEmail = email;
            adminPass = pass;
        }
    }
}
