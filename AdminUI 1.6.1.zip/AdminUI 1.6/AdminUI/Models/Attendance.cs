﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdminUI.Models
{
    internal class Attendance
    {
        public string Name { get; set; }
        public string Status { get; set; }
        public string TimeIn { get; set; }
        public string Remarks { get; set; }
        public string Ministry { get; set; }
        public string Zone { get; set; }
        public string Chapel { get; set; }

        // New fields
        public string Comment { get; set; } = "No comment";
        public string EventUid { get; set; }
        public string MemberUid { get; set; }
    }
}
