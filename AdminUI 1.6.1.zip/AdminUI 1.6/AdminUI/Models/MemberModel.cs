﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdminUI.Models
{
    public class MemberModel
    {
        public string MemberID { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public string ContactNumber { get; set; }
        public string HomeAddress { get; set; }
        public string Transparochial { get; set; } // ✅ This must be present
        public string Ministry { get; set; }
        public string Chapel { get; set; }
        public string Position { get; set; }
        public string Zone { get; set; }
        public string Username { get; set; }
        public string Email { get; set; }
        public string RegisteredAt { get; set; }
        public string Role { get; set; }
        public bool Approved { get; set; }

        public string MemberStatus { get; set; }
    }
    public class EventData
    {
        public string EventID { get; set; }
        public string EventName { get; set; }
        public string EventDate { get; set; }

        public string EventTime { get; set; }
        public string EventType { get; set; }
        public string EventVenue { get; set; } // 👈 Added
        public string EventDescription { get; set; }
        public string Published { get; set; }
    }

    public class ComboBoxItem
    {
        public string Text { get; set; }
        public string Value { get; set; }

        public ComboBoxItem(string text, string value)
        {
            Text = text;
            Value = value;
        }

        public override string ToString()
        {
            return Text; // This controls what appears in the ComboBox
        }
    }


}
