﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdminUI.Models
{
    public class AnnouncementData
    {
        public string AnnouncementID { get; set; }
        public string AnnouncementName { get; set; }
        public string Description { get; set; }
        public string Reminders { get; set; }
        public string Notes { get; set; }
        public string DateCreated { get; set; }
        public string TimeCreated { get; set; }
        public string PublishedBy { get; set; }
    }
}
