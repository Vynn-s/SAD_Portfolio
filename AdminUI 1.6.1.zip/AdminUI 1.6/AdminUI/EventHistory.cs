﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using AdminUI.Models;
using FireSharp.Config;
using FireSharp.Interfaces;
using FireSharp.Response;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace AdminUI
{
    public partial class EventHistory : Form
    {
        private readonly string _eventId;
        private readonly IFirebaseClient _client;

        public EventHistory(string eventId)
        {
            InitializeComponent();
            _eventId = eventId;

            // Initialize Firebase client
            IFirebaseConfig config = new FirebaseConfig
            {
                AuthSecret = "mA771wfHHaDuyceGgGRt0Bf15LvkqN92pW4h6hbK",
                BasePath = "https://web-based-event-scheduling-default-rtdb.firebaseio.com/"
            };
            _client = new FireSharp.FirebaseClient(config);

            LoadAttendanceData();
        }

        private async void LoadAttendanceData()
        {
            try
            {
                if (_client == null)
                {
                    MessageBox.Show("Firebase connection failed");
                    return;
                }

                FirebaseResponse response = await _client.GetAsync($"attendances/{_eventId}");
                if (response.Body == "null")
                {
                    MessageBox.Show("No attendance records found for this event.");
                    return;
                }

                // Parse and display the data
                var attendees = JsonConvert.DeserializeObject<Dictionary<string, Attendance>>(response.Body);
                dataGridView1.Rows.Clear();

                foreach (var attendee in attendees.Values)
                {
                    dataGridView1.Rows.Add(
                        attendee.Name,
                        attendee.TimeIn,
                        attendee.Status,
                        attendee.Remarks
                    );
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading attendance: {ex.Message}");
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private async void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadAttendanceData();
        }

        private async void btnExportCSV_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView1.Rows.Count == 0)
                {
                    MessageBox.Show("No data to export.");
                    return;
                }

                SaveFileDialog saveFileDialog = new SaveFileDialog
                {
                    Filter = "CSV files (*.csv)|*.csv",
                    FileName = $"EventAttendance_{_eventId}_{DateTime.Now:yyyyMMdd}.csv"
                };

                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    using (System.IO.StreamWriter file =
                        new System.IO.StreamWriter(saveFileDialog.FileName))
                    {
                        // Write headers
                        file.WriteLine("Name,Time In,Status,Remarks,Ministry,Zone,Chapel");

                        // Write data
                        foreach (DataGridViewRow row in dataGridView1.Rows)
                        {
                            if (!row.IsNewRow)
                            {
                                file.WriteLine(
                                    $"\"{row.Cells[0].Value}\"," +
                                    $"\"{row.Cells[1].Value}\"," +
                                    $"\"{row.Cells[2].Value}\"," +
                                    $"\"{row.Cells[3].Value}\"," +
                                    $"\"{row.Cells[4].Value}\"," +
                                    $"\"{row.Cells[5].Value}\"," +
                                    $"\"{row.Cells[6].Value}\""
                                );
                            }
                        }
                    }

                    MessageBox.Show("Data exported successfully!", "Success",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error exporting data: {ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}