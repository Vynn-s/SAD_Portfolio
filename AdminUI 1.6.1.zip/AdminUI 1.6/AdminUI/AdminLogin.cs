﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FireSharp.Config;
using FireSharp.Interfaces;
using FireSharp.Response;
using System.Security.Cryptography;
using AdminUI.Models;



namespace AdminUI
{
    public partial class AdminLogin : Form
    {
        IFirebaseConfig config = new FireSharp.Config.FirebaseConfig
        {
            AuthSecret = "mA771wfHHaDuyceGgGRt0Bf15LvkqN92pW4h6hbK",
            BasePath = "https://web-based-event-scheduling-default-rtdb.firebaseio.com/"
        };

        IFirebaseClient client;

        public AdminLogin()
        {
            InitializeComponent();
            this.Load += AdminLogin_Load;
        }
        private async void testConnectionBtn_Click(object sender, EventArgs e)
        {
            try
            {
                client = new FireSharp.FirebaseClient(config);
                if (client != null)
                {
                    var response = await client.GetAsync("test");
                    MessageBox.Show("Connection successful!");
                }
                else
                {
                    MessageBox.Show("Client is null. Check config.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Test failed: " + ex.Message);
            }
        }

        private void AdminLogin_Load(object sender, EventArgs e)
        {
            try
            {
                client = new FireSharp.FirebaseClient(config);
                if (client == null)
                {
                    MessageBox.Show("Firebase client is null. Please check your AuthSecret and BasePath.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Firebase connection error:\n\n" + ex.Message);
            }
        }



        private void guna2HtmlLabel9_Click(object sender, EventArgs e)
        {

        }

        private void guna2HtmlLabel10_Click(object sender, EventArgs e)
        {

        }

        private void emailAdmin_TextChanged(object sender, EventArgs e)
        {

        }

        private void passAdmin_TextChanged(object sender, EventArgs e)
        {

        }

        private async void loginBtn_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(emailAdmin.Text) || string.IsNullOrWhiteSpace(passAdmin.Text))
            {
                MessageBox.Show("Please enter your username/email and password.");
                return;
            }

            if (client == null)
            {
                MessageBox.Show("Firebase client not initialized.");
                return;
            }

            try
            {
                FirebaseResponse response = await client.GetAsync("admins");
                var data = response.ResultAs<Dictionary<string, AdminModel>>();

                if (data == null)
                {
                    MessageBox.Show("No admin data found.");
                    return;
                }

                string input = emailAdmin.Text;
                string hashedPass = HashPassword(passAdmin.Text);

                var matchedAdmin = data.Values.FirstOrDefault(a =>
                    (a.adminEmail == input || a.adminUsername == input) && a.adminPass == hashedPass);

                if (matchedAdmin != null)
                {
                    MessageBox.Show("Login successful!");
                    this.Hide();

                    Home homeForm = new Home(matchedAdmin); // Pass admin to Home
                    homeForm.Show();
                }
                else
                {
                    MessageBox.Show("Invalid login credentials.");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Login error: " + ex.Message);
            }
        }

        private string HashPassword(string password)
        {
            using (SHA256 sha256Hash = SHA256.Create())
            {
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder builder = new StringBuilder();
                foreach (byte b in bytes)
                    builder.Append(b.ToString("x2"));
                return builder.ToString();
            }
        }

    }
}
