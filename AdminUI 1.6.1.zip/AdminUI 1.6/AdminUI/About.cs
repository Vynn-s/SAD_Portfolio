﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AdminUI
{
    public partial class About : Form
    {
        public About()
        {
            InitializeComponent();
        }
        private string GetDayWithSuffix(int day)
        {
            if (day >= 11 && day <= 13)
                return day + "th";

            switch (day % 10)
            {
                case 1: return day + "st";
                case 2: return day + "nd";
                case 3: return day + "rd";
                default: return day + "th";
            }
        }

        private void monthLabel_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            UpdateTimeAndDate();
        }

        private void About_Load(object sender, EventArgs e)
        {
            timer1.Start();
            UpdateTimeAndDate();

            this.ControlBox = false;
        }
        private void UpdateTimeAndDate()
        {
            DateTime philippineTime = TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.UtcNow, "Singapore Standard Time");

            // Set formatted date on label
            string dayName = philippineTime.ToString("dddd");        // e.g., Friday
            string monthName = philippineTime.ToString("MMMM");      // e.g., May
            string dayWithSuffix = GetDayWithSuffix(philippineTime.Day); // e.g., 20th

            monthLabel.Text = $"{dayName}, {dayWithSuffix} {monthName}";
        }
    }
}
